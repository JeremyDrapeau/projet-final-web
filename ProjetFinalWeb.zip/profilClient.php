<?php include_once("inc/header.php"); ?>
<?php if(isset($_SESSION['client'])){ 
     $cm = new ClientManager($db);
     $client = new Client($_REQUEST);
     $row = $cm->get_client_info($_SESSION['client'])
     ?>
    <div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 class="pc" id="en19">Votre profil</h1>
            <div class="notPc">
                <h1  id="en19b">Votre profil</h1>
                <p></p>
            </div>
        </div>
</div>


    <fieldset class="profil">
        <div class="grid-container"></div>
            <legend>Informations</legend>
            <div class="pfp">
                <img class="pc" src="./pfp/<?php echo $row['cli_img']; ?>" alt="PFP" width="60" height="60">
            </div>
            <div class="grid-item">
                <label for="username">Username : </label>
                <?php echo $row['cli_username']; ?>
            </div>
            <div  class="grid-item">
                <label id="en20" for="prenom">Prénom: </label>
                <?php echo $row['cli_prenom']; ?>
            </div>
            <div class="grid-item">
                <label  id="en21" for="nom">Nom: </label>
                <?php echo $row['cli_nom']; ?>
            </div>
            <div class="grid-item">
                <label id="en22" for="courriel">Courriel: </label>
                <?php echo $row['cli_courriel']; ?>
            </div>
            <div class="grid-item">
                <label id="en23" for="adresse">Adresse: </label>
                <?php echo $row['adr_adresse']; ?>
            </div>
            <div class="grid-item">
                <label id="en24"  for="ville">Ville: </label>
                <?php echo $row['adr_ville']; ?>
            </div>
            <div class="grid-item">
                <label for="province">Province: </label>
                <?php echo $row['prv_nom']; ?>
            </div>

            <div class="grid-item">
                <label id="en25" for="codePostal">Code postal: </label>
                <?php echo $row['adr_codePostal']; ?>
            </div>

            <div class="grid-item">
                <label id="en26" for="tel">Téléphone: </label>
                <?php echo $row['cli_telephone']; ?>
            </div>
            <div class="notConnectedInfo">
                <a id="en27" href="traitement.php?action=logout" class="button black bigButton">Déconnexion</a>
            </div>
            </fieldset>
    </fieldset>
    <div class="notConnectedInfo">
        <a id="en28" href="modifierClient.php" class="button black bigButton">Modifier</a>
    </div>
        <?php } else { ?>
<div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 id="en29" class="pc">Connectez-vous pour consulter votre profil</h1>
            <div class="notPc">
                <h1 id="en30">Connectez-vous</h1>
                <p id="en31">pour consulter votre profil</p>
            </div>
        </div>
</div>

<?php } ?>
<?php include_once("inc/footer.php"); ?>