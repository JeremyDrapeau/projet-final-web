<?php include_once("inc/header.php"); ?>

<?php if(isset($_SESSION['client'])){ ?>
    <div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 id="en34" class="pc">Vous êtes déja connecté</h1>
            <div class="notPc">
                <h1 id="en34b">Vous êtes déja connecté</h1>
                <p></p>
            </div>
        </div>
</div>
        <?php } else { ?>

<div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 id="en30" class="pc">Connexion</h1>
            <div class="notPc">
                <h1 id="en30b">Connexion</h1>
                <p></p>
            </div>
        </div>
    </div>

<form action="traitement.php" method="post" class="login">

    <div class="center">
        <div class="grid-container">
                <div class="grid-item">
                <label id="en35" for="username" class="null">Nom d'utilisateur: </label>
                <br>
                <input type="text" name="username" id="username" class="input" required>
            </div>

            <div class="grid-item">
                <label id="en32" for="mdp" class="null">Mot de passe: </label>
                <br>
                <input type="password" name="mdp" id="mdp" class="input" required>
            </div>
        <div class="grid-container">
        <input type="hidden" name="action" value="connexion">

        <div class="notConnectedInfo">
            <button id="en30"  type="submit" class="button black bigButton">Connexion</button>
        </div>
    </div>
</form>
<?php } ?>
<?php include_once("inc/footer.php"); ?>