<?php include_once("inc/header.php");
?>
<?php if(isset($_SESSION['client'])){ 
         echo $_SESSION['client'];
         $cm = new ClientManager($db);
         $client = new Client($_REQUEST);
         $row = $cm->get_client_info($_SESSION['client'])
         ?>
    <div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 class="pc">Modification</h1>
            <div class="notPc">
                <h1>Modification</h1>
                <p></p>
            </div>
        </div>
</div>

<form action="traitement.php" method="post" class="register" enctype="multipart/form-data">
    <fieldset class="profil">
            <legend>Informations</legend>
            <div class="pfp">
                <img class="pc" src="./pfp/<?php echo $row['cli_img']; ?>" alt="PFP" width="60" height="60">
            </div>
            <input class="profilePicture" type="file" name="fileToUpload" id="fileToUpload">
        <div class="grid-container"></div>
            <div class="grid-item">
                <label for="username">Username : </label>
                <input type="text" name="username" id="username" value="<?php echo $row['cli_username']; ?>" required>
            </div>
            <div class="grid-item">
                <label id="en20" for="prenom">Prénom: </label>
                <input type="text" name="prenom" id="prenom" value="<?php echo $row['cli_prenom']; ?>" required>
            </div>
            <div class="grid-item">
                <label id="en21" for="nom">Nom: </label>
                <input type="text" name="nom" id="nom" value="<?php echo $row['cli_nom']; ?>" required>
            </div>
            <div class="grid-item">
                <label id="en22" for="courriel">Courriel: </label>
                <input type="email" name="courriel" id="courriel" value="<?php echo $row['cli_courriel']; ?>" required>
            </div>
            <div class="grid-item">
                <label id="en32" for="mdp">Mot de passe: </label>
                <input type="password" name="mdp" id="mdp" value="<?php echo $row['cli_mdp']; ?>" required>
            </div>
            <div class="grid-item">
                <label id="en23" for="adresse">Adresse: </label>
                <input type="text" name="adresse" id="adresse" value="<?php echo $row['adr_adresse']; ?>" required>
                <input type="hidden" name="adresseId" id="adresseId" value="<?php echo $row['cli_adresseId']; ?>">
            </div>
            <div class="grid-item">
                <label id="en24" for="ville">Ville: </label>
                <input type="text" name="ville" id="ville" value="<?php echo $row['adr_ville']; ?>" required>
            </div>
            <div class="grid-item">
                <label for="province">Province: </label>
                <select name="province" id="province">
                    <?php 
                        $query = $db->prepare("SELECT prv_id, prv_nom FROM tblProvince");
                        $query->execute();

                        while ($provinceRow = $query->fetch(PDO::FETCH_ASSOC)) {
                            $selected = ($provinceRow['prv_id'] == $row['adr_provinceId']) ? 'selected' : '';
                            echo '<option value="' . $provinceRow['prv_id'] . '" ' . $selected . '>' . $provinceRow['prv_nom'] . '</option>';
                        }
                    ?>
                </select>
            </div>

            <div class="grid-item">
                <label id="en25" for="codePostal">Code postal: </label>
                <input type="text" name="codePostal" id="codePostal" value="<?php echo $row['adr_codePostal']; ?>" required>
            </div>

            <div class="grid-item">
                <label id="en26" for="tel">Téléphone: </label>
                <input type="tel" name="tel" id="tel" value="<?php echo $row['cli_telephone']; ?>" required>
            </div>

    </fieldset>
    <div class="notConnectedInfo">
        <input type="hidden" name="action" value="modification">
        <button id="en28" type="submit" class="button black bigButton">Modifier</button>
    </div>
</form>
        <?php } else { ?>
<div class="notConnectedInfo">
    <div class="nexto">
        <img src="./img/user.svg" alt="User" >
        <h1 id="en33" class="pc">Vous n'êtes pas connecté</h1>
        <div class="notPc">
            <h1 id="en28">Vous n'êtes pas connecté</h1>
            <p></p>
</div>
</div class="notConnectedInfo">
        <a id="en30" href="./connexionClient.php" class="button black bigButton">Connexion</a>
    </div>
<?php } ?>
<?php include_once("inc/footer.php"); ?>