//JAVASCIRPT FOR SUPPORT SECTION
//Create Ticket form
function checkMistake(event) {
    event.preventDefault();
    if (document.getElementById("titre").value == "") {
        alert("Veuillez entrer du texte dans le champ de titre.");
        return;
    }
    if (document.getElementById("message").value == "") {
        alert("Veuillez entrer un message pour votre ticket");
        return;
    }
    this.submit();
}
document.getElementById("createTicketForm").addEventListener("submit", checkMistake);