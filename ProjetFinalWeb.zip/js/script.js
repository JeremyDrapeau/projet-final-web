function triggerBurger(){
    document.querySelector(".burgerMenu").classList.toggle("see")
}

document.getElementById("burger").addEventListener('click', triggerBurger);
document.getElementById("closeBurger").addEventListener('click', triggerBurger);

function triggerLangue(event) {

    document.getElementById("en").classList.toggle("hide");
    document.getElementById("fr").classList.toggle("hide");

    if (event.target.id === "en"){
        setCookie("language", "en", 30);
        traduction();
    }
    else{
        setCookie("language", "fr", 30);
        location.reload();
    }
}

document.addEventListener("DOMContentLoaded", function () {
    let lang = getCookie("language");
    if(lang === 'en'){
        traduction();
    }
});
function traduction() {
            const texts = [
                {id: "en1", newText: '<img src="./img/cart.svg" alt="Panier">Cart</a>'},
                {id: "en2", newText: '<img src="./img/user.svg" alt="user">Profile</a>'},
                {id: "en3", newText: 'Login'},
                {id: "en4", newText: 'Sign up'},
                {id: "en5", newText: 'Home'},
                {id: "en6", newText: 'Products'},
                { id: "en1b", newText: '<img src="./img/cart.svg" alt="Panier">Cart</a>' },
                { id: "en2b", newText: '<img src="./img/user.svg" alt="user">Profile</a>' },
                { id: "en3b", newText: 'Login' },
                { id: "en4b", newText: 'Sign up' },
                { id: "en5b", newText: 'Home' },
                { id: "en6b", newText: 'Products' },
                {id: "en7", newText: 'Welcome to MicroTechno'},
                {
                    id: "en8",
                    newText: 'Discover our selection of powerful, compact mini-computers tailored to your needs. Cutting-edge technology, competitive prices, and quality service await you. Focus on the essentials with MicroTechno!'
                },
                {id: "en9", newText: 'Support at your disposal'},
                {
                    id: "en10",
                    newText: 'Need help? Our team is here for you. Open a ticket, track your requests, and leave comments for fast and personalized support. At MicroTechno, your satisfaction is our priority!'
                },
                {id: "en11", newText: 'A wide choice of products'},
                {
                    id: "en12",
                    newText: 'Explore our extensive catalog of mini-computers adapted to all your needs. Performance, compactness and innovation: find the perfect product for your projects on MicroTechno!'
                },
                {id: "en13", newText: 'A dedicated customer area'},
                {
                    id: "en14",
                    newText: 'Enjoy a simple and efficient customer system. Create your account to track your orders, manage your information, and access exclusive offers. With MicroTechno, everything is designed to make your life easier!'
                },
                {id: "en15", newText: 'Manage your favorite products'},
                {
                    id: "en16",
                    newText: 'Add your favorite products to your cart and keep track of what interests you. Simplify your purchases with our convenient and organized system on MicroTechno!'
                },
                {id: "en17", newText: 'A simplified purchasing and delivery system'},
                {
                    id: "en18",
                    newText: 'Order with ease and receive your products quickly thanks to our reliable delivery service. With MicroTechno, your purchases are in good hands!'
                },
                {id: "btn1", newText: 'Login'},
                {id: "btn2", newText: 'Support'},
                {id: "btn3", newText: 'Produits'},
                {id: "btn4", newText: 'Sign up'},
                {id: "btn5", newText: 'Pay'},
                {id: "en19", newText: 'Your profile'},
                { id: "en19b", newText: 'Your profile'},
                {id: "en20", newText: 'First name : '},
                {id: "en21", newText: 'Last name : '},
                {id: "en22", newText: 'E-mail : '},
                {id: "en23", newText: 'Address : '},
                {id: "en24", newText: 'City : '},
                {id: "en25", newText: 'Postal code : '},
                {id: "en26", newText: 'Phone : '},
                { id: "en27", newText: 'Log out'},
                { id: "en28", newText: 'Modify'},
                { id: "en29", newText: 'Log in to check your profile'},
                {id: "en30", newText: 'Log in'},
                { id: "en30b", newText: 'Log in'},
                { id: "en31", newText: 'to check your profile'},
                {id: "en32", newText: 'Password : '},
                { id: "en33", newText: 'You are not logged in'},
                { id: "en34", newText: 'You are already logged in'},
                { id: "en34b", newText: 'You are already logged in'},
                { id: "en35", newText: 'Username : '},
                { id: "en36", newText: 'Brands : '},
                { id: "en37a1", newText: 'All'},
                { id: "en37a2", newText: 'All'},
                { id: "en37a3", newText: 'All'},
                { id: "en38", newText: 'Model : '},
                { id: "en39", newText: 'Processor : '},
                { id: "en40", newText: 'Max. price : '},
                { id: "en41", newText: 'Min. price : '},
                { id: "en42", newText: 'Filter inventory'},
                { id: "en43", newText: 'RAM'},
                { id: "en44", newText: 'Price'},
                { id: "en45", newText: 'Add to cart'},
                { id: "en46", newText: 'Our inventory'},
                { id: "panierSuccess", newText: 'Item has been addes to cart!'},
                { id: "en36e", newText: 'Brands : '},
                { id: "en38e", newText: 'Model : '},
                { id: "en39e", newText: 'Processor : '},
                {id: "en47", newText: 'Cart'},
                { id: "en48", newText: 'See more'},
                { id: "panierError", newText: 'Item could not be added to cart anymore! Please try again'},
                { id: "en49", newText: 'Storage : '},
                { id: "en50", newText: 'RAM : '},
                { id: "en51", newText: 'Sign up' },
                { id: "en51e1", newText: 'Sign up' },
                { id: "en51e2", newText: 'Sign up' },
                { id: "createTicketTitle", newText: 'Creating a support ticket'},
                { id: "en52", newText: 'Ticket title : '},
                { id: "en53", newText: 'Log in to check your tickets'},
                { id: "supportH1", newText: 'Support for computers'},
                { id: "en54", newText: 'Are you having problems with any of the devices purchased from our store?'},
                { id: "en55", newText: 'Create a ticket'},
                { id: "supportDescription", newText: 'Please select a product from the featured products page to continue.'},
                { id: "en56", newText: 'See products'},
                { id: "en57", newText: 'Our mission: To help you all the way'},
                { id: "en58", newText: "At MicroTechno™, we are dedicated to providing you with exceptional support service. We are committed to providing you with an easy-to-use forum-style place to open tickets that describe your problem. After you open your ticket, other users of our website, as well as our administrators, will be able to answer your questions. In case the problem requires further investigation, we will contact you to schedule a meeting or offer you possible options to resolve the problem." },
                { id: "en59", newText: 'A guarantee that takes care of your mind' },
                { id: "en60", newText: "MicroTechno™'s exceptional warranty keeps your mind at ease. With its LEGENDARY 2-year warranty, your devices are covered for the majority of everyday problems: bad soldering, viruses in the software, non-functional port... In short, you are in good hands."},
                { id: "1f", newText: 'Home' },
                {id: "2f", newText: 'Products' },
                { id: "3f", newText: 'Login' },
                { id: "4f", newText: 'Cart' },
                { id: "5f", newText: 'Payment' },
                { id: "6f", newText: 'Sign in' },
                { id: "7f", newText: 'Login' },
                { id: "en61", newText: 'Delivery'},
                { id: "en62", newText: 'Payment'},
                { id: "en63", newText: 'Confirm'},
                { id: "en64", newText: 'Summary'},
                { id: "en61d", newText: 'Delivery'},
                { id: "en61l", newText: 'Delivery'},
                { id: "en65", newText: '*Only in Canada'},
                { id: "continuer", newText: 'Continue'},
                { id: "panierSuccess", newText: 'Item has been added to cart!'},
                { id: "en66", newText: 'Credit' },
                { id: "en67", newText: 'Gift card' },
                { id: "en68", newText: 'Method' },
                { id: "continuer2", newText: 'Continue' },
                { id: "en69", newText: 'Summary'},
                { id: "en70", newText: 'Delivery'},
                {id: "en71", newText: 'Delivery' },
                { id: "en72", newText: '*Only in Canada' },
                { id: "en73", newText: 'Address : '},
                { id: "en74", newText: 'City : '},
                { id: "en75", newText: 'Postal code : '},
                { id: "en76", newText: 'Phone : '},
                { id: "en77", newText: 'Method : '},
                { id: "en78", newText: 'Method : '},
                { id: "en79", newText: 'Cancel : '},
                { id: "en80", newText: 'Choose'},
                { id: "en81", newText: 'Nothing'},
                { id: "en82", newText: 'Dog' },
                { id: "en83", newText: 'Cat' },
                { id: "en84", newText: 'Raccoon'},
                { id: "en85", newText: 'Fox : '},
                { id: "en86", newText: 'Cancel'},
                { id: "en87", newText: 'Cart empty,'},
                { id: "en88", newText: ' add products'},
                { id: "en89", newText: 'Products'},
                { id: "en90", newText: 'Log in'},
                { id: "en91", newText: 'to pay'},
                { id: "en92", newText: 'Log in'},
                { id: "en93", newText: 'Method'},
                { id: "en94", newText: 'User already exists'},
                { id: "en94b", newText: 'User already exists'},
                { id: "en95", newText: 'Sign up'},
                { id: "en96", newText: 'Sign up successful!'},
                { id: "en96b", newText: 'Sign up successful!'},
                { id: "en97", newText: 'Welcome'},
                { id: "en97b", newText: 'Welcome'},
                { id: "en98", newText: 'Wrong info!'},
                { id: "en98b", newText: 'Wrong info!'},
                { id: "en99", newText: 'Bye!'},
                { id: "en99b", newText: 'Bye!'},
                { id: "en100", newText: 'User already exists!'},
                { id: "en100b", newText: 'User already exists!'},
                { id: "en101", newText: 'User modified!'},
                { id: "en101b", newText: 'User modified!'},
                { id: "en102", newText: 'User modified!'},
                { id: "en102b", newText: 'User modified!'},
                { id: "en103", newText: 'Your cart is empty'},
                { id: "en104", newText: 'see our products'},
                { id: "en105", newText: 'Products'},
                { id: "en106", newText: 'Log in'},
                { id: "en107", newText: 'to see your cart'},
                { id: "en108", newText: 'Log in'},
            ];
            texts.forEach(item => {
                if (document.getElementById(item.id))
                    document.getElementById(item.id).innerHTML = item.newText;
            });
}
// Add event listeners to both buttons for language toggle
document.getElementById("en").addEventListener('click', triggerLangue);
document.getElementById("fr").addEventListener('click', triggerLangue);
function total() {
    let elements = document.getElementsByClassName("ant_productInfoPrice");

    if (elements.length === 0) {
        document.getElementById("total").innerHTML = "Total : 0$";
        document.getElementById("items").innerHTML = "Items : 0";
        document.getElementById("payer").innerHTML = "Produits";
        document.getElementById("payer").setAttribute("href", "./inventaire.php");
        return;
    }

    let total = 0;
    for (let element of elements) {
        total += parseFloat(element.innerHTML.slice(0, -1).trim());
    }

    document.getElementById("total").innerHTML = `Total : ${total}$`;
    document.getElementById("items").innerHTML = `Items : ${elements.length}`;
}

function removeItem(event){

    let itemId = event.target.parentElement.getAttribute('data-id');
    let userId = document.getElementById('cartInfo').getAttribute('data-userid');

    //Voila des source utile :
    // https://borstch.com/blog/making-get-post-put-and-delete-requests-with-fetch
    // https://rapidapi.com/guides/query-parameters-fetch
    fetch('./inc/removeItem.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ item: itemId, user: userId }),
    })
    .then((response) => {
        if (!response.ok) {
            throw new Error('HTTP error ' + response.status);
        }
        return response.text();
    })
    .then((data) => {
        console.log('Success:', data);
        event.target.parentElement.remove();
        total();
    })
    .catch(error => console.error('Error : ',error));
}

for (let element of document.getElementsByClassName("ant_productInfoRemove")) {
    element.addEventListener("click", removeItem);
}

function valider(condition, element) {
    condition ? element.classList.remove('ant_wrong') : element.classList.add('ant_wrong');
    return condition;
}

function payment(){
    const phoneReg = new RegExp("^(\\+\\d{1,2}\\s?)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$");
    const cpReg = new RegExp("^[A-Za-z]\\d[A-Za-z]\\d[A-Za-z]\\d$");
    const villeReg = new RegExp("^.{1,20}$");
    const addressReg = new RegExp("^.{1,255}$");

    let phone = document.getElementById('tel');
    let address = document.getElementById('address');
    let city = document.getElementById('city');
    let cp = document.getElementById('cp');

    let error = false;

    if(!valider(phoneReg.test(phone.value), phone)) error = true;
    if(!valider(cpReg.test(cp.value), cp)) error = true;
    if(!valider(addressReg.test(address.value), address)) error = true;
    if(!valider(villeReg.test(city.value), city)) error = true;

    if(error)
        return;

    document.getElementById('res_cp').innerHTML = cp.value;
    document.getElementById('res_tel').innerHTML = phone.value;
    document.getElementById('res_city').innerHTML = city.value;
    document.getElementById('res_address').innerHTML = address.value;

    let province = document.getElementById('province');
    let nom = province.children[province.value - 1].innerText;
    document.getElementById('res_prov').innerHTML = nom;

    document.getElementById("payCircle").classList.add('ant_active');
    document.getElementById("delivery").classList.add('hide');
    document.getElementById("methode").classList.remove('hide');
}
document.getElementById('continuer').addEventListener('click', payment);

function payment2(){

    let credit = document.getElementById('credit');
    let paypal = document.getElementById('paypal');
    let gift = document.getElementById('gift');

    const giftCardReg = new RegExp("^[a-zA-Z0-9]{3}[\\s.-]?[a-zA-Z0-9]{3}[\\s.-]?[a-zA-Z0-9]{3}$");
    let giftCard = document.getElementById('code');

    if(!paypal.checked && !credit.checked && !gift.checked) return;

    if(gift.checked && !valider(giftCardReg.test(giftCard.value), giftCard)) return;

    let methode
    if(paypal.checked) methode = "PayPal";
    else if(credit.checked) methode = "Crédit";
    else if(gift.checked) methode = "Carte cadeau";
    document.getElementById("methodePay").innerHTML = methode;
    console.log(methode);

    document.getElementById("confCircle").classList.add('ant_active');
    document.getElementById("methode").classList.add('hide');
    document.getElementById("confirm").classList.remove('hide');
}
document.getElementById('continuer2').addEventListener('click', payment2);

function captchaSubmit(){
    let option = document.getElementById('captchaRep');
    if(option.value === option.parentElement.getAttribute('data-captcha')){
        document.getElementById('formulaire').submit();
    }else{
        document.getElementById('captcha').classList.add('hide');
    }
}
document.getElementById('captchaConf').addEventListener('click', captchaSubmit);
function captchaCancel(){
    document.getElementById('captcha').classList.add('hide');
}
document.getElementById('captchaAnul').addEventListener('click', captchaCancel);
function payment3(event){
    event.preventDefault();
    document.getElementById('captcha').classList.remove('hide');
    let img = document.getElementById('captchaImg');

    let randome = Math.floor(Math.random() * 5) + 1;
    img.parentElement.setAttribute('data-captcha',randome);
    img.setAttribute('src', `img/captcha${randome}.jpg`);


}
document.getElementById('terminer').addEventListener('click', payment3);


function paymentChange(event){
    document.getElementById('paypalPay').classList.add('hide');
    document.getElementById('creditCard').classList.add('hide');
    document.getElementById('gifted').classList.add('hide');
    document.getElementById(event.target.value).classList.remove('hide');
}
for (let element of document.getElementsByClassName('ant_radio')) {
    element.addEventListener("change", paymentChange);
}

function sortTable(index) {

    /*-------Mettre table en ordre----------*/
    let table = document.getElementById("tableInventaire");
    let body = document.getElementById("tableBody");
    let head = document.getElementById("tableHead");
    let rows = Array.from(body.querySelectorAll('tr'));
    let headTh = Array.from(head.querySelectorAll("th"));

    //Mettre ordre ascendant, sauf si c'est ascendant -> mettre descendant a la place
    let ifAscendant = table.dataset.sortOrder !== 'asc';
    table.dataset.sortOrder = ifAscendant ? 'asc' : 'desc';

    //boucle pour sort les chaque row de rows
    rows.sort((a, b) => {
        let aText = a.children[index].textContent.trim().toLowerCase();
        let bText = b.children[index].textContent.trim().toLowerCase();

        if (aText < bText) return ifAscendant ? -1 : 1;
        if (aText > bText) return ifAscendant ? 1 : -1;
        return 0;
    });
    //Réattacher rows au body
    rows.forEach(row => body.appendChild(row));

    /*-----------Flèches qui montre ordre---------*/
    if(index == 1) { //Marque
        switchOrder(headTh[1]);
        headTh[2].textContent = "Modèle";
        headTh[3].textContent = "Processeur";
        headTh[4].textContent = "Mémoire";
        headTh[5].textContent = "Prix";
    }
    else if (index == 2) { //Modele
        headTh[1].textContent = "Marque";
        switchOrder(headTh[2]);
        headTh[3].textContent = "Processeur";
        headTh[4].textContent = "Mémoire";
        headTh[5].textContent = "Prix";
    }
    else if (index == 3) { //Processeur
        headTh[1].textContent = "Marque";
        headTh[2].textContent = "Modèle";
        switchOrder(headTh[3]);
        headTh[4].textContent = "Mémoire";
        headTh[5].textContent = "Prix";
    }
    else if (index == 4) { //Mémoire
        headTh[1].textContent = "Marque";
        headTh[2].textContent = "Modèle";
        headTh[3].textContent = "Processeur";
        switchOrder(headTh[4]);
        headTh[5].textContent = "Prix";
    }
    else if (index == 5) { //Prix
        headTh[1].textContent = "Marque";
        headTh[2].textContent = "Modèle";
        headTh[3].textContent = "Processeur";
        headTh[4].textContent = "Mémoire";
        switchOrder(headTh[5]);
    }
}

function switchOrder(selectedTag) {

    if(selectedTag.textContent.includes('▲')) {
        selectedTag.textContent = selectedTag.textContent.substring(0, selectedTag.textContent.length -2);
        selectedTag.textContent += " ▼";
    }
    else if (selectedTag.textContent.includes("▼")) {
        selectedTag.textContent = selectedTag.textContent.substring(0, selectedTag.textContent.length -2);
        selectedTag.textContent += " ▲";
    }
    else {
        selectedTag.textContent += " ▲";
    }
}

function hideAlert() {

    document.getElementById("customAlert").classList.toggle("hidden");
}

//Cookie functions
function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    let expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for(let i = 0; i <ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
}
function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}

