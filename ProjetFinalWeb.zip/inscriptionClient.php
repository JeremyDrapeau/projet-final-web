<?php include_once("inc/header.php");
//Table test
/*
$servername = "localhost";  // Replace with your server if different
$username = "root";         // Your MySQL username
$password = "";             // Your MySQL password (empty by default in XAMPP, WAMP, etc.)
$dbname = "Ordinateur";     // The database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to get data from tblClient
$sql = "SELECT cli_id, cli_username, cli_nom, cli_prenom, cli_courriel, cli_telephone, cli_mdp FROM tblClient";
$result = $conn->query($sql);

// Check if there are results
if ($result->num_rows > 0) {
    // Output data of each row
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Email</th>
                <th>Telephone</th>
                <th>Password</th>
            </tr>";

    // Fetch the rows
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["cli_id"] . "</td>
                <td>" . $row["cli_username"] . "</td>
                <td>" . $row["cli_nom"] . "</td>
                <td>" . $row["cli_prenom"] . "</td>
                <td>" . $row["cli_courriel"] . "</td>
                <td>" . $row["cli_telephone"] . "</td>
                <td>" . $row["cli_mdp"] . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "0 results found";
}

// Close the connection
$conn->close();*/
 ?>
<?php if(isset($_SESSION['client'])){ ?>
    <div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 id="en34" class="pc">Vous êtes déja connecté</h1>
            <div class="notPc">
                <h1 id="en34" >Vous êtes déja connecté</h1>
                <p></p>
            </div>
        </div>
</div>
        <?php } else { ?>
<div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 id="en51" class="pc">Inscription</h1>
            <div class="notPc">
                <h1 id="en51e1">Inscription</h1>
                <p></p>
            </div>
        </div>
</div>

<form action="traitement.php" method="post" class="register">
    <fieldset class="profil">
        <div class="grid-container"></div>
            <legend>Informations</legend>
            <div class="grid-item">
                <label for="username">Username : </label>
                <input type="text" name="username" id="username" required>
            </div>
            <div class="grid-item">
                <label id="en20" for="prenom">Prénom: </label>
                <input type="text" name="prenom" id="prenom" required>
            </div>
            <div class="grid-item">
                <label id="en21" for="nom">Nom: </label>
                <input type="text" name="nom" id="nom" required>
            </div>
            <div class="grid-item">
                <label id="en22" for="courriel">Courriel: </label>
                <input type="email" name="courriel" id="courriel" required>
            </div>
            <div class="grid-item">
                <label id="en32" for="mdp">Mot de passe: </label>
                <input type="password" name="mdp" id="mdp" required>
            </div>
            <div class="grid-item">
                <label id="en23" for="adresse">Adresse: </label>
                <input type="text" name="adresse" id="adresse" required>
            </div>
            <div class="grid-item">
                <label id="en24" for="ville">Ville: </label>
                <input type="text" name="ville" id="ville" required>
            </div>
            <div class="grid-item">
                <label for="province">Province: </label>
                <select name="province" id="province">
                    <?php 
                        $query = $db->prepare("SELECT prv_id, prv_nom FROM tblProvince");
                        $query->execute();

                        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
                            echo '<option value="' . $row['prv_id'] . '">' . $row['prv_nom'] . '</option>';
                        }
                    ?>
                </select>
            </div>

            <div class="grid-item">
                <label id="en25" for="codePostal">Code postal: </label>
                <input type="text" name="codePostal" id="codePostal" required>
            </div>

            <div class="grid-item">
                <label id="en26" for="tel">Téléphone: </label>
                <input type="tel" name="tel" id="tel" required>
            </div>

    </fieldset>
    <div class="notConnectedInfo">
        <input type="hidden" name="action" value="inscription">
        <button id="en51e2" type="submit" class="button black bigButton">Inscription</button>
    </div>
</form>
<?php } ?>
<?php include_once("inc/footer.php"); ?>