
<?php 
    include_once("inc/header.php");
    include_once("inc/pretraitement.php");
?>

<?php 
    if(isset($_REQUEST['action'])) {
        if($_REQUEST['action'] == "inscription") {
            
            $cm = new ClientManager($db);
            $client = new Client($_REQUEST);
            if(!$cm->insertClient($client)){ ?>
                <div class="notConnectedInfo">
                    <div class="nexto">
                        <img src="./img/user.svg" alt="User" >
                        <h1 id="94" class="pc">Utilisateur existe déja!</h1>
                        <div class="notPc">
                            <h1 id="94b">Utilisateur existe déja!</h1>
                            <p></p>
                        </div>
                    </div>
                </div>
            
            <div class="notConnectedInfo">
            <a id="en95" href="inscriptionClient.php" class="button black bigButton">Inscription</a>
            </div>
            <?php }else{ ?>

    <div class="notConnectedInfo">
        <div class="nexto">
            <img src="./img/user.svg" alt="User" >
            <h1 id="en96" class="pc">Inscription réussie!</h1>
            <div class="notPc">
                <h1 id="en96b">Inscription réussie!</h1>
                <p></p>
            </div>
        </div>
    </div>
        <ul class="center">
            <li>Profil
                <ul>
                <li><span>Username: </span><?= $client->get_username(); ?></li>
                    <li><span id="en20">Prénom: </span><?= $client->get_prenom(); ?></li>
                    <li><span id="en21">Nom: </span><?= $client->get_nom(); ?></li>
                    <li><span id="en22">Courriel: </span><?= $client->get_courriel(); ?></li>
                    <li><span id="en23">Adresse: </span><?= $client->get_adresse(); ?></li>
                    <li><span id="en24">Ville: </span><?= $client->get_ville(); ?></li>
                    <li><span>Province: </span><?= $client->get_province(); ?></li>
                    <li><span id="en25">Code postal: </span><?= $client->get_codePostal(); ?></li>
                    <li><span id="en26">Téléphone: </span><?= $client->get_tel(); ?></li>
                </ul>
            </li>
        </ul>

    <?php }} elseif ($_REQUEST['action'] == "connexion"){ 
        $cm = new ClientManager($db);
        $client = new Client($_REQUEST);
        ?>
        <?php   
            if($cm->connectionClient($client->get_username(), $client->get_mdp())){
         ?>
            <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 id="en97" class="pc">Bienvenue <?php echo $client->get_username(); ?>!</h1>
                    <div class="notPc">
                        <h1 id="en97b">Bienvenue <?php echo $client->get_username(); ?>!</h1>
                        <p></p>
                    </div>
                </div>
            </div>
            <meta http-equiv="refresh" content="1; URL=profilClient.php" />
        <?php } else{ ?>
            <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 id="en97" class="pc">Information incorrecte!</h1>
                    <div class="notPc">
                        <h1 id="en97b">Information incorrecte!</h1>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="notConnectedInfo">
            <a id="en92" href="connexionClient.php" class="button black bigButton">Connexion</a>
            </div>
    <?php }} elseif ($_REQUEST['action'] == "logout"){ ?>
        <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 id="en99" class="pc">Au revoir !</h1>
                    <div class="notPc">
                        <h1 id="en99b">Au revoir !</h1>
                        <p></p>
                    </div>
                </div>
            </div>
        <meta http-equiv="refresh" content="1; URL=index.php" />
    <?php }elseif ($_REQUEST['action'] == "modification"){
        $cm = new ClientManager($db);
        $client = new Client($_REQUEST);
        $client->set_pfp($_FILES["fileToUpload"]["name"]);
        if(!$cm->modifyClient($client)){ ?>
            <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User">
                    <h1 id="en100" class="pc">Utilisateur existe déja!</h1>
                    <div class="notPc">
                        <h1 id="en100b">Utilisateur existe déja!</h1>
                        <p></p>
                    </div>
                </div>
            </div>
        
        <div class="notConnectedInfo">
        <a id="en28" href="modifierClient.php" class="button black bigButton">Modifier</a>
        </div>
        <?php }else{ 
            if (isset($_FILES["fileToUpload"]) && $_FILES["fileToUpload"]["error"] == 0) {
            $target_dir = __DIR__ . '/pfp/';
            $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            
            // Check if image file is a actual image or fake image
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) {?>
            <?php
            $uploadOk = 1;
            } else { ?>
                <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 class="pc">Not an image</h1>
                    <div class="notPc">
                        <h1>Not an image</h1>
                        <p></p>
                    </div>
                </div>
            </div> <?php
            $uploadOk = 0;
            }
            
            // Check file size
            if ($_FILES["fileToUpload"]["size"] > 50000000) { ?>
                <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 class="pc">File too big</h1>
                    <div class="notPc">
                        <h1>File too big</h1>
                        <p></p>
                    </div>
                </div>
            </div> 
              <?php
              $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") { ?>
                <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 class="pc">png, jpeg ou jpg</h1>
                    <div class="notPc">
                        <h1>Le fichier</h1>
                        <p>png, jpeg ou jpg</p>
                    </div>
                </div>
            </div> 
              <?php
              $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) { 
            // if everything is ok, try to upload file
            } else {
              if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) { ?>
              
                <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 id="en101" class="pc">Modification réussie!</h1>
                    <div class="notPc">
                        <h1 id="en101b">Modification réussie!</h1>
                        <p></p>
                    </div>
                </div>
            </div><?php } else {  ?>
                                <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 class="pc">Error</h1>
                    <div class="notPc">
                        <h1>Error</h1>
                        <p></p>
                    </div>
                </div>
            </div> 
                <?php }}
            }else{
            ?>
                <div class="notConnectedInfo">
                <div class="nexto">
                    <img src="./img/user.svg" alt="User" >
                    <h1 id="en102" class="pc">Modification réussie!</h1>
                    <div class="notPc">
                        <h1 id="en102b">Modification réussie!</h1>
                        <p></p>
                    </div>
                </div>
            </div>

            <meta http-equiv="refresh" content="1; URL=profilClient.php" />
<?php }}}} ?>
<?php include_once("inc/footer.php"); ?>