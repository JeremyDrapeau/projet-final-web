<?php include_once("inc/header.php") ?>
<div class="ind_bigContainer">

    <!-- Les texte c'est genere par AI (pas le html ni css, just le text)-->

    <section class="ind_container">
        <img src="./img/logo.svg">
        <div class="ind_text">
            <h1 id="en7">Bienvenue sur MicroTechno</h1>
            <p id="en8">Découvrez notre sélection de mini-ordinateurs performants, compacts et adaptés à tous vos besoins. Technologie de pointe, prix compétitifs, et service de qualité vous attendent. Passez à l'essentiel avec MicroTechno !</p>
            <a id="btn1" href="./connexionClient.php" class="button bigButton black">Connexion</a>
        </div>
    </section>
    <section class="ind_container">
        <div class="ind_text">
            <h1 id="en9" >Support à votre écoute</h1>
            <p id="en10" >Besoin d’aide ? Notre équipe est là pour vous. Ouvrez un ticket, suivez vos demandes, et laissez des commentaires pour un support rapide et personnalisé. Chez MicroTechno, votre satisfaction est notre priorité !</p>
            <a href="./support.php" class="button bigButton black">Support</a>
        </div>
        <img src="./img/support.jpg">
    </section>
    <section class="ind_container">
        <img src="./img/produits.jpg">
        <div class="ind_text">
            <h1 id="en11" >Un large choix de produits</h1>
            <p id="en12">Explorez notre vaste catalogue de mini-ordinateurs adaptés à tous vos besoins. Performances, compacité et innovation : trouvez le produit parfait pour vos projets sur MicroTechno !</p>
            <a id="btn2" href="./inventaire.php" class="button bigButton black">Produits</a>
        </div>
    </section>
    <section class="ind_container">
        <div class="ind_text">
            <h1 id="en13">Un espace client dédié</h1>
            <p id="en14">Profitez d’un système client simple et efficace. Créez votre compte pour suivre vos commandes, gérer vos informations, et accéder à des offres exclusives. Avec MicroTechno, tout est pensé pour vous faciliter la vie !</p>
            <a id="btn3" href="./inscriptionClient.php" class="button bigButton black">Inscription</a>
        </div>
        <img src="./img/user.png">
    </section>
    <section class="ind_container">
        <img src="./img/panier.webp">
        <div class="ind_text">
            <h1 id="en15" >Gérez vos produits favoris</h1>
            <p id="en16">Ajoutez vos produits préférés à votre panier et gardez une trace de ce qui vous intéresse. Simplifiez vos achats avec notre système pratique et organisé sur MicroTechno !</p>
            <a id="btn4" href="./cart.php" class="button bigButton black">Panier</a>
        </div>
    </section>
    <section class="ind_container">
        <div class="ind_text">
            <h1 id="en17" >Un système d'achat et de livraison simplifié</h1>
            <p id="en18">Commandez en toute simplicité et recevez vos produits rapidement grâce à notre service de livraison fiable. Avec MicroTechno, vos achats sont entre de bonnes mains !</p>
            <a id="btn5" href="./pay.php" class="button bigButton black">Payer</a>
        </div>
        <img src="./img/payer.jpeg">
    </section>
</div>
<?php include_once("inc/footer.php") ?>