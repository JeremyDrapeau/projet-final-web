<?php
include_once ('../class/pdoFactory.php');
include_once ('../class/classCartManager.php');

$db = PDOFactory::getMySQLConnection();
$cartManager = new CartManager($db);

if (isset($_POST['item']) && isset($_POST['user'])) {
    $itemId = $_POST['item'];
    $userId = $_POST['user'];
    $cartManager->removeItemFromCart($userId, $itemId);
    echo 'item '.$itemId.' supprimer de utilisateur '.$userId;
}
?>