<?php
include_once("class/classAdresseManager.php");
include_once("class/classDeliveryManager.php");
include_once("class/classDeliveryComputerManager.php");
include_once("class/classCartManager.php");

if (isset($_POST['addDelivery']) && isset($_SESSION['client'])) {
    $am = new AdresseManager($db);
    $dm = new DeliveryManager($db);
    $dcm = new DeliveryComputerManager($db);
    $cm = new CartManager($db);
    $clientId = $_SESSION['client'];

    $last = $am->addAdresse($_POST['address'], $_POST['city'], $_POST['province'], $_POST['cp']);
    date_default_timezone_set('America/New_York');
    $deliveryId = $dm->addDelivery($clientId ,$last, date('Y-m-d'), $_POST['total']);

    $items = $cm->getComputersByClientID($_SESSION['client']);
    foreach ($items as $item) {
        $dcm->addComputerWithDeliveryId($item['ComputerID'] ,$deliveryId );
    }

    unset($_POST);
    header("Location: ./cart.php");
}?>