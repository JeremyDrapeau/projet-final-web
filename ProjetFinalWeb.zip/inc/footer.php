</main>
<footer>
    <div class="brand">
        <img src="./img/logo.svg" alt="Logo">
        <p>MicroTechno</p>
    </div>
    <div class="navLinks">
        <a id="1f" href="./index.php">Accueil</a>
        <a id="2f" href="./inventaire.php">Produit</a>
        <a id="3f" href="./support.php">Support</a>
        <a id="4f" href="./cart.php">Panier</a>
        <a id="5f" href="./pay.php">Paiement</a>
        <a id="6f" href="./inscriptionClient.php">Inscription</a>
        <a id="7f" href="./connexionClient.php">Connexion</a>
    </div>
    <p class="copyright">©2024 MicroTechno</p>
</footer>
</body>
</html>
