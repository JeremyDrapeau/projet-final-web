<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once("class/classClient.php");

if (isset($_REQUEST['action']) && $_REQUEST['action'] == "connexion"){
    $cm = new ClientManager($db); 
    $client = $cm->clientExiste($_REQUEST['username'], $_REQUEST['mdp']);
    
} else if (isset($_REQUEST['action']) && $_REQUEST['action'] == "logout"){
    $_SESSION = array();
    session_destroy(); 
} ?>