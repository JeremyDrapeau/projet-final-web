<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
} 


require_once './class/classClient.php'; 
require_once './class/classClientManager.php'; 
require_once './class/pdoFactory.php'; 

$db = PDOFactory::getMySQLConnection();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="icon" type="image/x-icon" href="./img/favicon.ico">
    <script src="./js/script.js" defer></script>
    <title>MicroTechno</title>
</head>

<body>
<nav>
    <a class="brand" href="./index.php">
        <img src="./img/logo.svg" alt="Logo">
        <p>MicroTechno</p>
    </a>
    <div class="navLinks">
        <a id="en5" href="./index.php">Accueil</a>
        <a id="en6" href="./inventaire.php">Produits</a>
        <?php 
        if (isset($_GET['produit']))
            echo "<a href='./support.php?produit=" . $_GET['produit'] . "'>Support</a>";
        else
            echo "<a href='./support.php'>Support</a>";
        ?>
    </div>
    <div class="nexto">
    <div class="connect">
        <?php if(isset($_SESSION['client'])){ ?>
            <a id="en1" href="./cart.php" class="button"><img src="./img/cart.svg" alt="Panier">Panier</a>
            <a id="en2" href="./profilClient.php" class="button"><img src="./img/user.svg" alt="user">Profil</a>
            <?php } else { ?>
            <a id="en3" href="./connexionClient.php" class="button black">Connexion</a>
            <a id="en4" href="./inscriptionClient.php" class="button black">Inscription</a>
            <?php } ?>
            <?php
            $cookieLang = 'null';
            if(isset($_COOKIE["language"]) ) {
                $cookieLang = $_COOKIE["language"];
            } ?>
        </div>
        <a id="fr" class="button black <?php if($cookieLang == 'fr' || $cookieLang == 'null') {echo 'hide';} ?>"><img src="./img/fr.webp" alt="Panier">Français</a>
        <a id="en" class="button black <?php if($cookieLang == 'en') {echo 'hide';} ?>"><img src="./img/en.webp" alt="user">English</a>
        <div id="burger" class="burgerMenuIcon">
            <img src="./img/burgerMenu.svg" alt="Logo">
        </div>
    </div>
</nav>
    <div class="burgerMenu" id="burger">
        <a id="en5b" href="./index.php">Accueil</a>
        <a id="en6b"  href="./inventaire.php">Produits</a>
        <?php 
        if (isset($_GET['produit']))
            echo "<a href='./support.php?produit=" . $_GET['produit'] . "'>Support</a>";
        else
            echo "<a href='./support.php'>Support</a>";
        ?>
        <?php if(isset($_SESSION['client'])){ ?>
        <a id="en1b" href="./cart.php" class="button"><img src="./img/cart.svg" alt="Panier">Panier</a>
        <a id="en2b" href="./profilClient.php" class="button"><img src="./img/user.svg" alt="user">Profil</a>
        <?php } else { ?>
        <a id="en3b" href="./connexionClient.php" class="button black">Connexion</a>
        <a id="en4b" href="./inscriptionClient.php" class="button black">Inscription</a>
        <?php } ?>
        <img src="./img/uparrow.svg" alt="Close" id="closeBurger">
    </div>
        
<main>
