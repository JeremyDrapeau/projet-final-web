<?php include_once("inc/header.php") ?>
<?php 
    //Ce qui s'affiche si l'utilisateur ne provient pas d'une des pages de l'un des produits.
    if (!isset($_GET['produit']))
        include_once('./support/supportDescription.php'); //Affiche la page qui décrit le support que la compagnie offre.
    else
        include_once('support/ticket.php');
    if (isset($_POST['message'])) {
        
    }
?>
    
<?php
for ($i = 0; $i < 10; $i++)
    echo "<br>";
?>
<?php include_once("inc/footer.php") ?>