<?php
include_once "./inc/header.php";
include_once "./class/classTicketManager.php";
?>
<?php 
if (isset($_SESSION['client'])) {
    echo "
    <div id='createTicketPage'>
        <h1 id='createTicketTitle'>Création d'un ticket de support</h1>
        <form id='createTicketForm' action='./support.php?produit=";
        echo $_GET['produit'];
        echo "' method='post'>
            <div class='newTicketTitre'>
                <label id='en52' for='titre'>Titre du ticket : </label>
                <input type='text' id='titre' name='titre'>
            </div>
            <div class='newTicketMessage'>
                <label for='message'>Message : </label>
                <input type='text' id='message' name='message'>
            </div>
            <input id='submitTicketCreation' type='submit' value='Submit'>
        </form>
    </div>
    <script src='./js/supportScript.js' defer></script>    
    ";
}
else {
    echo "<h1 id='en53' class='middleCreate'>Veuillez vous connecter pour créer un ticket!</h1>";
}
?>
<?php
include_once "./inc/footer.php";
?>