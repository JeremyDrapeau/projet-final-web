<?php
include_once("./inc/header.php");
include_once ("./inc/commandPretraitement.php");
include_once ("./class/classClient.php");
?>
<div class="ant_payContainer">
    <?php if (isSet($_SESSION['client'])) :
        $userId = $_SESSION['client'];

        include_once("./class/classCartManager.php");
        include_once("./class/classComputerManager.php");

        $cartManager = new CartManager($db);
        $computerManager = new ComputerManager($db);

        $sousTotal = $cartManager->getTotalPriceByClientID($userId);
        $items = $cartManager->getTotalItemsByClientID($userId);

        if($items > 0 ) :

            $tps = round($sousTotal * 0.05, 2);
            $tva = round($sousTotal * 0.09975, 2);

            $total = $sousTotal + $tps + $tva;

            $userComputers = $cartManager->getComputersByClientID($userId);
            ?>
            <div class="ant_progress">
                <span>
                    <span class="ant_circle ant_active">1</span>
                    <span id="en61">Livraison</span>
                </span>
                <span class="ant_tiret"></span>
                <span>
                    <span id="payCircle" class="ant_circle">2</span>
                    <span id="en62">Paiement</span>
                </span>
                <span class="ant_tiret"></span>
                <span>
                    <span id="confCircle" class="ant_circle">3</span>
                    <span id="en63">Confirmation</span>
                </span>
            </div>
        <form class="ant_form" id="formulaire" action="./pay.php" method="POST">
            <fieldset id="delivery" class="ant_fieldset ant_field1">
                <div class="ant_bigBox ant_summary">
                    <h1 id="en64">Résumer</h1>
                    <div class="ant_box">
                        <?php foreach ($userComputers as $computerData) :
                            $computer = $computerManager->getComputerByID($computerData['ComputerID']);
                            if ($computer) : ?>
                            <div class="ant_row">
                                <p><?= $computer->getBrand() . ' - ' . $computer->getModel() ?></p>
                                <p><?= $computer->getPrice() . '$' ?></p>
                            </div>
                            <?php endif;
                        endforeach; ?>
                        <hr>
                        <div class="ant_row">
                            <p>Articles</p>
                            <p><?= $sousTotal ?>$</p>
                        </div>
                        <div class="ant_row">
                            <p>TPS</p>
                            <p><?= $tps ?>$</p>
                        </div>
                        <div class="ant_row">
                            <p>TVA</p>
                            <p><?= $tva ?>$</p>
                            </div>
                        <div class="ant_row">
                            <p id="en61d">Livraison</p>
                            <p>--$</p>
                        </div>
                        <div class="ant_row">
                            <p>Total</p>
                            <p class="ant_accent"><?= $total ?>$</p>
                        </div>
                    </div>
                </div>
                <div class="ant_bigBox ant_delivery">
                    <h1 id="en61l">Livraison <span id="en65" class="ant_mention">*Seulement au Canada</span></h1>
                    <div class="ant_box">
                        <div class="ant_row">
                            <label id="en26" for="tel">Téléphone</label>
                            <input type="tel" id="tel" name="tel" class="ant_input">
                        </div>
                        <div class="ant_row">
                            <label id="en23" for="address">Adresse</label>
                            <input type="text" id="address" name="address" class="ant_input" >
                        </div>
                        <div class="ant_row">
                            <label id="en24" for="city">Ville</label>
                            <input type="text" id="city" name="city" class="ant_input" >
                        </div>
                        <div class="ant_row">
                            <label for="province">Province</label>
                            <select id="province" name="province" class="ant_input" >
                                <option value="1" >Alberta</option>
                                <option value="2">Colombie-Britannique</option>
                                <option value="3">Île-du-Prince-Édouard</option>
                                <option value="4">Manitoba</option>
                                <option value="5">Nouveau-Brunswick</option>
                                <option value="6">Nouvelle-Écosse</option>
                                <option value="7">Nunavut</option>
                                <option value="8">Ontario</option>
                                <option value="9">Saskatchewan</option>
                                <option value="10">Terre-Neuve-et-Labrador</option>
                                <option value="11">Territoires du Nord-Ouest</option>
                                <option value="12" selected>Québec</option>
                                <option value="13">Yukon</option>
                            </select>
                        </div>
                        <div class="ant_row">
                            <label id="en25" for="cp">Code postal</label>
                            <input type="text" id="cp" name="cp" class="ant_input" >
                        </div>
                    </div>
                </div>
                <div class="ant_bigBox ant_continue">
                    <img src="./img/card.svg" alt="CreditCard">
                    <a id="continuer" class="button black bigButton">Continuer</a>
                </div>
            </fieldset>
            <fieldset id="methode" class="ant_fieldset ant_field2 hide">
                <div class="ant_bigBox ant_methode">
                    <h1 id="en93">Méthode</h1>
                    <div class="ant_box">
                        <div class="ant_row">
                            <label id="en66" for="credit">Crédit</label>
                            <input type="radio" id="credit" name="paymentWay" value="creditCard" class="ant_input ant_radio" >
                        </div>
                        <div class="ant_row">
                            <label for="paypal">PayPal</label>
                            <input type="radio" id="paypal" name="paymentWay" value="paypalPay" class="ant_input ant_radio" >
                        </div>
                        <div class="ant_row">
                            <label id="en67" for="gift">Carte cadeau</label>
                            <input type="radio" id="gift" name="paymentWay" value="gifted" class="ant_input ant_radio" >
                        </div>
                        <hr>
                        <div id="paymentMethode">
                            <div class="ant_row hide" id="creditCard">
                                <label id="en68" for="credit">Méthode :</label>
                                <select id="credit">
                                    <option>Visa</option>
                                    <option>MasterCard</option>
                                    <option>American Express</option>
                                    <option>Tangerine</option>
                                </select>
                            </div>
                            <div class="ant_row hide" id="paypalPay">
                                <a href="https://developer.paypal.com/studio/checkout/fastlane/integrate" target="_blank" id="paypal" class="button black bigButton">PayPal</a>
                            </div>
                            <div class="ant_row hide" id="gifted">
                                <label for="code">Code</label>
                                <input type="text" id="code" name="code" class="ant_input" placeholder="xxx-xxx-xxx" >
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ant_bigBox ant_continue ant_ontop">
                    <h1>Total : <?= $total ?>$ </h1>
                    <a id="continuer2" class="button black bigButton">Continuer</a>
                </div>
            </fieldset>
            <fieldset id="confirm" class="ant_fieldset ant_field3 hide">
                <div class="ant_bigBox ant_summary">
                    <h1 id="en69">Résumer</h1>
                    <div class="ant_box">
                        <?php foreach ($userComputers as $computerData) :
                            $computer = $computerManager->getComputerByID($computerData['ComputerID']);
                            if ($computer) : ?>
                                <div class="ant_row">
                                    <p><?= $computer->getBrand() . ' - ' . $computer->getModel() ?></p>
                                    <p><?= $computer->getPrice() . '$' ?></p>
                                </div>
                            <?php endif;
                        endforeach; ?>
                        <hr>
                        <div class="ant_row">
                            <p>Articles</p>
                            <p><?= $sousTotal ?>$</p>
                        </div>
                        <div class="ant_row">
                            <p>TPS</p>
                            <p><?= $tps ?>$</p>
                        </div>
                        <div class="ant_row">
                            <p>TVA</p>
                            <p><?= $tva ?>$</p>
                        </div>
                        <div class="ant_row">
                            <p id="en70">Livraison</p>
                            <p><?= $sousTotal * 0.06 ?>$</p>
                        </div>
                        <div class="ant_row">
                            <p>Total</p>
                            <p class="ant_accent"><?= $total = $total + $sousTotal * 0.06 ?>$</p>
                        </div>
                    </div>
                </div>
                <div class="ant_bigBox ant_delivery">
                    <h1 id="en71">Livraison <span id="en72" class="ant_mention">*Seulement au Canada</span></h1>
                    <div class="ant_box">
                        <div class="ant_row">
                            <p id="en76">Téléphone</p>
                            <p id="res_tel"></p>
                        </div>
                        <div class="ant_row">
                            <p id="en73">Adresse</p>
                            <p id="res_address"></p>
                        </div>
                        <div class="ant_row">
                            <p id="en74">Ville</p>
                            <p id="res_city"></p>
                        </div>
                        <div class="ant_row">
                            <p>Province</p>
                            <p id="res_prov"></p>
                        </div>
                        <div class="ant_row">
                            <p id="en75">Code postal</p>
                            <p id="res_cp"></p>
                        </div>
                    </div>
                </div>
                <div class="ant_bigBox ant_methode">
                    <h1 id="en77">Méthode</h1>
                    <div class="ant_box">
                        <div class="ant_row">
                            <p id="en78">Méthode</p>
                            <p id="methodePay"></p>
                        </div>
                    </div>
                </div>
                <div class="ant_bigBox ant_continue">
                    <input type="submit" value="Terminer" id="terminer" class="button black bigButton">
                    <a id="en79" href="./cart.php" id="annuler" class="button bigButton">Annuler</a>
                </div>
                <div class="ant_captcha hide" id="captcha">
                    <img id="captchaImg" src="" alt="captcha">
                    <label id="en80" for="captchaRep">Selectionnez une réponse : </label>
                    <select id="captchaRep" name="captcha">
                        <option id="en81" value="0" selected>Rien</option>
                        <option id="en82" value="1">Chien</option>
                        <option id="en83" value="2">Chat</option>
                        <option id="en84" value="3">Raton</option>
                        <option value="4">Lion</option>
                        <option id="en85" value="5">Renard</option>
                    </select>
                    <a class="button black" id="captchaConf">Confirm</a>
                    <a class="button" id="captchaAnul">Annuler</a>
                </div>
            </fieldset>
            <input type="hidden" name="addDelivery" value="true">
            <input type="hidden" name="total" value="<?= $total ?>">
        </form>
        <?php else : ?>
            <div class="ant_infoBox">
                <img src="./img/money.svg" alt="Money">
                <h1 id="en87">Panier vide,<span id="en88" class="ant_infoBoxExtra"> ajouter des produits</span></h1>
                <a id="en89" href="./inventaire.php" class="button black bigButton">Produits</a>
            </div>
        <?php endif;
    else : ?>
        <div class="ant_infoBox">
            <img src="./img/money.svg" alt="Money">
            <h1 id="en90">Connectez-vous <span id="en91" class="ant_infoBoxExtra">pour Payer</span></h1>
            <a id="en91" href="./connexionClient.php" class="button black bigButton">Connexion</a>
        </div>
    <?php endif; ?>

</div>
<?php include_once("inc/footer.php"); ?>