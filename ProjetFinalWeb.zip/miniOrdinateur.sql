CREATE DATABASE IF NOT EXISTS Ordinateur;
USE Ordinateur;

CREATE TABLE tblProcesseur (
	pro_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	pro_nom VARCHAR(50) NOT NULL,
	pro_frequence VARCHAR(32) NOT NULL,
	pro_coeurs INT NOT NULL
);
CREATE TABLE tblMarque (
	mrq_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	mrq_nom VARCHAR(50) NOT NULL
);
CREATE TABLE  tblModele (
	mdl_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	mdl_nom VARCHAR(50)
);
CREATE TABLE  tblPort (
	prt_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	prt_nom VARCHAR(30)
);
CREATE TABLE tblMemoire (
	mem_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	mem_quantite VARCHAR(16) NOT NULL,
	mem_type VARCHAR(50) NOT NULL
);
CREATE TABLE tblStockage (
	stk_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	stk_quantite VARCHAR(16) NOT NULL
);
CREATE TABLE tblOrdinateur (
	ord_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	ord_processeurId INT UNSIGNED NOT NULL,
	ord_memoireId INT UNSIGNED NOT NULL,
	ord_marqueId INT UNSIGNED NOT NULL,
	ord_modeleId INT UNSIGNED NOT NULL,
	ord_prix INT NOT NULL,
	ord_quantite INT,
	ord_img VARCHAR(20)
);
CREATE TABLE tblClient (
	cli_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	cli_username VARCHAR(20) NOT NULL,
	cli_prenom VARCHAR(20),
	cli_nom VARCHAR(20) NOT NULL,
	cli_courriel VARCHAR(30) NOT NULL,
	cli_adresseId INT UNSIGNED,
	cli_telephone VARCHAR(12),
	cli_img VARCHAR(20),
	cli_mdp VARCHAR(20) NOT NULL
);
CREATE TABLE tblAdresse (
	adr_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	adr_adresse VARCHAR(255) NOT NULL,
	adr_ville VARCHAR(20) NOT NULL,
	adr_provinceId INT UNSIGNED,
	adr_codePostal VARCHAR(6) NOT NULL
);
CREATE TABLE tblProvince (
	prv_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	prv_nom VARCHAR(30) NOT NULL
);
CREATE TABLE tblLivraison (
	liv_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	liv_clientId INT UNSIGNED NOT NULL,
	liv_adresseId INT UNSIGNED NOT NULL,
	liv_date DATE NOT NULL,
	liv_prixTotal INT NOT NULL
);
CREATE TABLE tblTicket (
	tik_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	tik_clientId INT UNSIGNED NOT NULL,
	tik_ordId INT UNSIGNED NOT NULL,
	tik_titre VARCHAR(64) NOT NULL,
	tik_message VARCHAR(512) NOT NULL,
	tik_date DATE,
	tik_vote INT
);

CREATE TABLE tblPanier (
    pan_clientId INT UNSIGNED NOT NULL,
    pan_ordId INT UNSIGNED NOT NULL,
	pan_id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
);
CREATE TABLE tblOrdinateurPort (
	odp_portId INT UNSIGNED NOT NULL,
	odp_ordId INT UNSIGNED NOT NULL,
	PRIMARY KEY (odp_portId, odp_ordId)
);
CREATE TABLE tblOrdinateurStockage (
	ods_ordId INT UNSIGNED NOT NULL,
	ods_stockId INT UNSIGNED NOT NULL,
	PRIMARY KEY (ods_stockId, ods_ordId)
);
CREATE TABLE tblLivraisonOrdinateur (
	lvo_livraisonId INT UNSIGNED NOT NULL,
	lvo_ordId INT UNSIGNED NOT NULL,
	PRIMARY KEY (lvo_livraisonId, lvo_ordId)
);

ALTER TABLE tblClient
	ADD CONSTRAINT FK_adresseId_tblClient_tblAdresse FOREIGN KEY (cli_adresseId) REFERENCES tblAdresse (adr_id);

ALTER TABLE tblAdresse
	ADD CONSTRAINT FK_provinceId_tblAdresse_tblProvince FOREIGN KEY (adr_provinceId) REFERENCES tblProvince (prv_id);

ALTER TABLE tblLivraison
	ADD CONSTRAINT FK_adresseId_tblLivraison_tblAdresse FOREIGN KEY (liv_adresseId) REFERENCES tblAdresse (adr_id),
	ADD CONSTRAINT FK_clientId_tblLivraison_tblClient FOREIGN KEY (liv_clientId) REFERENCES tblClient (cli_id);

ALTER TABLE tblTicket
	ADD CONSTRAINT FK_clientId_tblTicket_tblClient FOREIGN KEY (tik_clientId) REFERENCES tblClient (cli_id),
	ADD CONSTRAINT FK_ordId_tblTicket_tblOrdinateur FOREIGN KEY (tik_ordId) REFERENCES tblOrdinateur (ord_id);

ALTER TABLE tblPanier
	ADD CONSTRAINT FK_ordId_tblPanier_tblOrdinateur FOREIGN KEY (pan_ordId) REFERENCES tblOrdinateur (ord_id),
	ADD CONSTRAINT FK_clientId_tblPanier_tblClient FOREIGN KEY (pan_clientId) REFERENCES tblClient (cli_id);

ALTER TABLE tblOrdinateurStockage
	ADD CONSTRAINT FK_ordId_tblOrdinateurStockage_tblOrdinateur FOREIGN KEY (ods_ordId) REFERENCES tblOrdinateur (ord_id),
	ADD CONSTRAINT FK_stockId_tblOrdinateurStockage_tblStockage FOREIGN KEY (ods_stockId) REFERENCES tblStockage (stk_id);

ALTER TABLE tblOrdinateurPort
	ADD CONSTRAINT FK_ordId_tblOrdinateurPort_tblOrdinateur FOREIGN KEY (odp_ordId) REFERENCES tblOrdinateur (ord_id),
	ADD CONSTRAINT FK_portId_tblOrdinateurPort_tblPort FOREIGN KEY (odp_portId) REFERENCES tblPort (prt_id);

ALTER TABLE tblLivraisonOrdinateur
	ADD CONSTRAINT FK_ordId_tblLivraisonOrdinateur_tblOrdinateur FOREIGN KEY (lvo_ordId) REFERENCES tblOrdinateur (ord_id),
	ADD CONSTRAINT FK_livraisonId_tblLivraisonOrdinateur_tblLivraison FOREIGN KEY (lvo_livraisonId) REFERENCES tblLivraison (liv_id);

INSERT INTO tblMarque (mrq_id, mrq_nom)
	VALUES 
	(1, 'Arduino'),
	(2, 'Asus'),
	(3, 'Beelink'),
	(4, 'HP'),
	(5, 'Intel'),
	(6, 'Lenovo'),
	(7, 'Libre Computer'),
	(8, 'LuckFox'),
	(9, 'Nvidia'),
	(10, 'Raspberry Pi'),
	(11, 'Via Technologis'),
	(12, 'Zimaboard')
	;

INSERT INTO tblModele (mdl_id, mdl_nom)
	VALUES
	(1, '5'),
	(2, 'Pico 2'),
	(3, 'UNO R4 Wifi'),
	(4, 'Mega 2560 Rev3'),
	(5, 'Nano'),
	(6, 'ExpertCenter PN65'),
	(7, 'EQ12'),
	(8, 'NUC 13 Pro'),
	(9, 'Elite t755 Thin Client'),
	(10, 'Jetson Orin Nano 8GB'),
	(11, 'IdeaCentre Mini 5i'),
	(12, 'Thinker Board 3'),
	(13, 'Thinker Board 3N PLUS'),
	(14, 'Thinker System 3N'),
	(15, 'VAB-950'),
	(16, '432 Single Board Server'),
	(17, 'Pico Plus RV1103'),
	(18, 'Sweet Potato AML-S905X-CC-V2'),
	(19, 'La Frite AML-S805X-AC'),
	(20, 'Renegade Elite ROC-RK3399-PC')
	;

INSERT INTO tblProcesseur (pro_id, pro_nom, pro_frequence, pro_coeurs)
	VALUES
	(1, 'AMD Ryzen V2546', '4 GHz', 6),
	(2, 'Arm Cortex-A53 (4 core version)', '1.4 GHz', 4),
	(3, 'Arm Cortex-A53 (8 core version)', '2.0 GHz', 8),
	(4, 'Arm Cortex-A55', '2.31 GHz', 4),
	(5, 'Arm Cortex-A7', '1.2 GHz', 1),
	(6, 'Arm Cortex-A72', '2.0 GHz', 2),
	(7, 'Arm Cortex-A76', '3.0 GHz', 4),
	(8, 'Arm Cortex-A78AE', '1.5 GHz', 6),
	(9, 'ATmega2560', '16.0 MHz', 2),
	(10, 'ATmega328', '16.0 MHz', 4),
	(11, 'ESP32-S3', '240.0 MHz', 4),
	(12, 'Intel Celeron N3450', '2.2 GHz', 4),
	(13, 'Intel Core i5 10400T', '4.3 GHz', 4),
	(14, 'Intel Core i7 1360P', '4-pc 5.0 GHz, 8-ec 3.7 GHz', 12),
	(15, 'Intel Core Ultra 155H', '4-pc 4.5 GHz, 8-ec 2.5 GHz', 12),
	(16, 'Intel N100', '3.4 GHz', 4),
	(17, 'RP2350', '150.0 MHz', 2)
	;

INSERT INTO tblMemoire (mem_id, mem_quantite, mem_type)
	VALUES
	(1, '2 KB, 1 KB', 'SRAM, EEPROM'),
	(2, '8 KB, 4 KB', 'SRAM, EEPROM'),
	(3, '512 KB', 'SRAM'),
	(4, '520 KB', 'something'),
	(5, '64 MB', 'DDR2 DRAM'),
	(6, '1 GB', 'DDR4 SDRAM'),
	(7, '2 GB', 'DDR4 SDRAM'),
	(8, '4 GB', 'LPDDR4'),
	(9, '4 GB', 'LPDDR4 SDRAM'),
	(11, '4 GB', 'LPDDR4X'),
	(12, '4 GB', 'LPDDR4X SDRAM'),
	(13, '8 GB', 'DDR4'),
	(14, '8 GB', 'LPDDR4X'),
	(15, '8 GB', 'DDR4 SO-DIMM'),
	(16, '8 GB', 'LPDDR5'),
	(17, '16 GB', 'DDR5 SO-DIMM'),
	(18, '24 GB', 'DDR5 SO-DIMM'),
	(19, '32 GB', 'DDR4 SO-DIMM')
	;

INSERT INTO tblStockage (stk_id, stk_quantite)
	VALUES
	(1, '0 B'),
	(2, '8 KB'),
	(3, '32 KB'),
	(4, '256 KB'),
	(5, '16 MB'),
	(6, '128 MB'),
	(7, '16 GB'),
	(8, '32 GB'),
	(9, '64 GB'),
	(10, '128 GB'),
	(11, '256 GB'),
	(12, '500 GB'),
	(13, '1 TB'),
	(14, '2 TB')
	;

INSERT INTO tblPort (prt_id, prt_nom)
	VALUES
	(1, '40-pin Header'),
	(2, '70-pin Header'),
	(3, 'Capteur Infrarouge (IR)'),
	(4, 'DC Port'),
	(5, 'DisplayPort'),
	(6, 'DMIC/DSPK'),
	(7, 'Gigabite Internet'),
	(8, 'HDMI'),
	(9, 'I2C'),
	(10, 'I2S'),
	(11, 'LVDS'),
	(12, 'Micro-HDMI'),
	(13, 'Micro-USB'),
	(14, 'Mini-DisplayPort'),
	(15, 'Mini-USB'),
	(16, 'MIPI DSI'),
	(17, 'Port COM (CAN)'),
	(18, 'PCIe'),
	(19, 'Port M.2'),
	(20, 'Port SIM'),
	(21, 'Port Audio 3.5mm'),
	(22, 'Port SATA'),
	(23, 'PWM'),
	(24, 'RS-232'),
	(25, 'RS-232/422/485'),
	(26, 'SPI'),
	(27, 'UART'),
	(28, 'USB-A 2.0'),
	(29, 'USB-A 3.0'),
	(30, 'USB-A 3.2'),
	(31, 'USB-B'),
	(32, 'USB-C'),
	(33, 'Port Micro-SD')
	;
INSERT INTO tblOrdinateur (ord_id, ord_processeurId, ord_memoireId, ord_marqueId, ord_modeleId, ord_prix, ord_quantite, ord_img)
	VALUES
	(1, 7, 12, 10, 1, 150, 20, '1.jpg'),
	(2, 17, 4, 10, 2, 45, 15, '2.jpg'),
	(3, 11, 3, 1, 3, 180, 30, '3.jpg'),
	(4, 10, 2, 1, 4, 75, 5, '4.jpg'),
	(5, 9, 1, 1, 5, 120, 10, '5.jpg'),
	(6, 15, 18, 2, 6, 200, 25, '6.jpg'),
	(7, 16, 17, 3, 7, 95, 12, '7.jpg'),
	(8, 14, 19, 5, 8, 65, 8, '8.jpg'),
	(9, 1, 15, 4, 9, 140, 30, '9.jpg'),
	(10, 8, 16, 9, 10, 50, 20, '10.jpg'),
	(11, 13, 13, 6, 11, 175, 18, '11.jpg'),
	(12, 4, 11, 2, 12, 110, 22, '12.jpg'),
	(13, 4, 11, 2, 13, 135, 14, '13.jpg'),
	(14, 4, 14, 2, 14, 100, 35, '14.jpg'),
	(15, 3, 11, 11, 15, 85, 3, '15.jpg'),
	(16, 12, 8, 12, 16, 55, 10, '16.jpg'),
	(17, 5, 5, 8, 17, 160, 28, '17.jpg'),
	(18, 2, 7, 7, 18, 130, 6, '18.jpg'),
	(19, 2, 6, 7, 19, 190, 12, '19.jpg'),
	(20, 6, 11, 7, 20, 105, 0, '20.jpg')
	;

INSERT INTO tblOrdinateurStockage (ods_ordId, ods_stockId)
	VALUES
	(1, 1),
	(2, 2),
	(3, 4),
	(4, 4),
	(5, 3),
	(6, 11), (6, 14),
	(7, 12),
	(8, 14),
	(9, 11),
	(10, 1),
	(11, 13), (11, 10),
	(12, 1),
	(13, 8),
	(14, 8), (14, 5),
	(15, 7),
	(16, 8),
	(17, 6),
	(18, 1),
	(19, 1),
	(20, 1)
	;

INSERT INTO tblOrdinateurPort (odp_ordId, odp_portId)
	VALUES
	(1, 12), (1, 29), (1, 28), (1, 7), (1, 18), (1, 32), (1, 1),
	(2, 1), (2, 13),
	(3, 32),
	(4, 2), (4, 31),
	(5, 15),
	(6, 32), (6, 30), (6, 28), (6, 8), (6, 7), (6, 4),
	(7, 8), (7, 32), (7, 7), (7, 30), (7, 4),
	(8, 8), (8, 21), (8, 32), (8, 30), (8, 28), (8, 7), (8, 4),
	(9, 30), (9, 28), (9, 32), (9, 5), (9, 7), (9, 4), (9, 18),
	(10, 18), (10, 7), (10, 5), (10, 8), (10, 30), (10, 28), (10, 27), (10, 26), (10, 10), (10, 9), (10, 17), (10, 6), (10, 23),
	(11, 30), (11, 32), (11, 21), (11, 7), (11, 8), (11, 5), (11, 4),
	(12, 8), (12, 16), (12, 21), (12, 30), (12, 28), (12, 13), (12, 1), (12, 4),
	(13, 8), (13, 11), (13, 5), (13, 19), (13, 20), (13, 21), (13, 32), (13, 30), (13, 28), (13, 1), (13, 4),
	(14, 8), (14, 21), (14, 32), (14, 30), (14, 24), (14, 25), (14, 17), (14, 19), (14, 7), (14, 20), (14, 4),
	(15, 8), (15, 28), (15, 13), (15, 7), (15, 4),
	(16, 14), (16, 22), (16, 7), (16, 29), (16, 18), (16, 4),
	(17, 32), (17, 1), (17, 7),
	(18, 28), (18, 7), (18, 3), (18, 8), (18, 32), (18, 1),
	(19, 28), (19, 8), (19, 1), (19, 13),
	(20, 32), (20, 8), (20, 7), (20, 28), (20, 3)
	;
		INSERT INTO tblProvince (prv_id, prv_nom)
	VALUES
	(1, 'Alberta'),
	(2, 'Colombie-Britannique'),
	(3, 'Île-du-Prince-Édouard'),
	(4, 'Manitoba'),
	(5, 'Nouveau-Brunswick'),
	(6, 'Nouvelle-Écosse'),
	(7, 'Nunavut'),
	(8, 'Ontario'),
	(9, 'Saskatchewan'),
	(10, 'Terre-Neuve-et-Labrador'),
	(11, 'Territoires du Nord-Ouest'),
	(12, 'Québec'),
	(13, 'Yukon')
	;
	
	INSERT INTO tblAdresse (adr_adresse, adr_ville, adr_provinceId, adr_codePostal)
	VALUES
    ('123 Rue Principale', 'Montréal', 1, 'H1A1A1'),
    ('456 Boulevard Saint-Laurent', 'Québec', 2, 'G1A1A1');
	
	INSERT INTO tblClient (cli_username, cli_nom, cli_courriel, cli_mdp, cli_adresseId)
	VALUES
    ('Roket', 'Antoine', 'antoine@gmail.com', 'secret321', 1),
    ('LucaWoof', 'Jéremy', 'Jeremy@gmail.com', 'secret123', 2);


	INSERT INTO tblPanier (pan_clientId, pan_ordId)
	VALUES
	(1,1),
	(1,7),
	(1,4),
	(1,8),
	(1,10),
	(1,15),
	(1,20)
	;

	INSERT INTO tblTicket (tik_clientId, tik_ordId, tik_titre, tik_message, tik_date, tik_vote)
	VALUES
	(1, 1, 'Problème de connexion', 'Je rencontre des difficultés pour me connecter à mon compte.', '2024-12-01', 5),
	(2, 2, 'Erreur de commande', 'La commande ne correspond pas à ce que j’ai commandé.', '2024-12-02', 8),
	(1, 3, 'Demande de remboursement', 'Je souhaite être remboursé pour une erreur.', '2024-12-03', 0),
	(2, 4, 'Problème de livraison', 'Le colis n’a toujours pas été livré après une semaine.', '2024-12-04', 2),
	(1, 5, 'Produit défectueux', 'Le produit reçu est endommagé.', '2024-12-05', 7),
	(2, 6, 'Question technique', 'Pouvez-vous expliquer comment utiliser ce produit ?', '2024-12-06', 6),
	(1, 7, 'Erreur dans la facture', 'La facture contient un montant incorrect.', '2024-12-07', 4),
	(2, 8, 'Retard de remboursement', 'Je n’ai pas reçu le remboursement promis.', '2024-12-08', 3),
	(1, 9, 'Problème de paiement', 'Je n’arrive pas à effectuer mon paiement.', '2024-12-09', 9),
	(2, 10, 'Modification de commande', 'Je voudrais modifier les articles de ma commande.', '2024-12-10', 0),
	(1, 11, 'Assistance technique', 'Besoin d’aide pour configurer mon compte.', '2024-12-01', 8),
	(2, 12, 'Réclamation', 'Je souhaite signaler un problème avec le service.', '2024-12-02', 5),
	(1, 13, 'Demande d’information', 'Pouvez-vous m’envoyer plus de détails sur ce produit ?', '2024-12-03', 0),
	(2, 14, 'Colis perdu', 'Le transporteur dit avoir livré mais je n’ai rien reçu.', '2024-12-04', 1),
	(1, 15, 'Erreur dans le produit reçu', 'Le produit reçu n’est pas celui commandé.', '2024-12-05', 7),
	(2, 16, 'Question sur la garantie', 'Combien de temps le produit est-il garanti ?', '2024-12-06', 6),
	(1, 17, 'Mise à jour des coordonnées', 'Je souhaite mettre à jour mes informations personnelles.', '2024-12-07', 0),
	(2, 18, 'Demande de support', 'Je ne parviens pas à accéder à une fonctionnalité.', '2024-12-08', 4);
