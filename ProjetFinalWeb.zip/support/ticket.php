<?php include_once "./class/classTicketManager.php"; ?>

<div id="supportMain">
    <div id="supportMainTitle">
        <img id="supportMainIcon" src="img/supportIcon.svg">
        <h1 id="supportH1">Support pour les ordinateurs <br id="en54"> Avez-vous des problèmes avec l'un des appareils achetés dans notre magasin?</h1>
    </div>
</div>
<?php
$_ticketManager = new TicketManager($db, $_GET['produit']);
$_ticketManager->displayProduct();
?>
<div class="supportAddButtonDiv">
<?php
if (isset($_SESSION['client'])) {
    echo "<a id='en54' class='supportCreateTicketButton' href='./createTicket.php?produit=" . $_GET['produit'] . "'>Créer un ticket</a>";
}
if (!empty($_POST)) {
    $_ticketManager->addTicketToComputer($_SESSION['client'], $_GET['produit'], $_POST['titre'], $_POST['message']);
}
?>
</div>
<div class="ticketArea">
    <?php
    $_ticketManager->displayAllTicket();
    ?>
</div>