<!-- Section qui est exécuté lorsque aucun produit n'a été sélectionné -->
<div id="supportMain">
    <div id="supportMainTitle">
        <img id="supportMainIcon" src="img/supportIcon.svg">
        <h1 id="supportH1">Support pour les ordinateurs <br id="en54"> Avez-vous des problèmes avec l'un des appareils achetés dans notre magasin?</h1>
    </div>
    <div id="supportMainNav">
        <p id="supportDescription">Veuillez sélectionner un produit dans la page des produits offert pour continuer</p>
        <a id="en56" href="inventaire.php" class="supportBiggerButton button black">Voir les produits</a> <!-- Changer le "href" lors de la prise de connaissance
                                                                                                  du nom de la page qui affiche tous les produit -->
    </div>
    <div id="supportContent">
        <div id="supportContentRow">
            <h2 id="en57">Notre mission : Vous aider jusqu'au boût</h2>
            <p id="en58">
                Chez MicroTechno™, nous nous dédions à vous rendre un service de support
                exceptionnel. Nous nous engageons à vous fournir un endroit simple d'utilisation
                de type forum à questions, afin de pouvoir ouvrir des tickets qui décrive votre problème.
                Après l'ouverture de votre ticket, les autres utilisateurs de notre site web, ainsi
                que nos administrateurs vont pouvoir répondre à vos question. Au cas où le problème
                requière de plus amples recherches, nous allons vous contacter afin de planifier une
                recontre ou vous proposer les options possibles afin de régler le problème.
            </p>
        </div>
        <div id="supportContentRow">
            <h2 id="en59">Une garantie qui vous soigne l'esprit</h2>
            <p id="en60">
                La garantie exceptionnelle de MicroTechno™ permet de garder votre esprit tranquille. Avec
                sa LÉGENDAIRE garantie de 2 ans, vos appareils sont couvert pour la majorité des problèmes
                de la vie de tous les jours : mauvaise(s) soudure(s), virus dans le software, port non
                fonctionnel... Bref, vous êtes entre bonnes mains.
            </p>
        </div>
    </div>
</div>