<?php include_once("./inc/header.php"); ?>
<div class="ant_container">

    <?php if (isSet($_SESSION['client'])) :
        $userId = $_SESSION['client'];

        include_once("./class/classCartManager.php");
        include_once("./class/classComputerManager.php");

        $cartManager = new CartManager($db);
        $computerManager = new ComputerManager($db);

        $userComputers = $cartManager->getComputersByClientID($userId);

        if (!empty($userComputers)) : ?>
            <div class="ant_cartInfo" id="cartInfo" data-userid="<?= $userId ?>">
                <div class="ant_nexto">
                    <img src="./img/cart.svg" alt="Panier" class="ant_icon-s1">
                    <div>
                        <h1 id="en47">Panier</h1>
                        <p id="total">Total : <?= $cartManager->getTotalPriceByClientID($userId) ?>$</p>
                        <p id="items">Items : <?= $cartManager->getTotalItemsByClientID($userId) ?></p>
                    </div>
                </div>
                <a id="btn5" href="./pay.php" class="button black bigButton" id="payer">Payer</a>
            </div>
            <?php foreach ($userComputers as $computerData) :
                $computer = $computerManager->getComputerByID($computerData['ComputerID']);
                if ($computer) : ?>
                    <div class="ant_productInfo" data-id="<?= $computer->getID() ?>">
                        <img src="./img/<?= $computer->getImage() ?>" alt="ImageProduit" class="ant_imgProduct">
                        <h3 class="ant_productInfoName"><?= $computer->getBrand() . ' - ' . $computer->getModel() ?></h3>
                        <h3 class="ant_productInfoPrice"><?= $computer->getPrice() . '$' ?></h3>
                        <img src="./img/remove.svg" alt="Remove" class="ant_productInfoRemove">
                        <ul>
                            <li id="en39">Processeur : <?= $computer->getProcessor() ?></li>
                            <li id="en43">Mémoire : <?= $computer->getMemory() ?></li>
                        </ul>
                        <a  id="en43" href="./produit.php?produit=<?= $computer->getID() ?>">Voir Plus</a>
                    </div>
                <?php endif;
            endforeach;
        else : ?>
            <div class="ant_infoBox">
                <img src="./img/cart.svg" alt="Panier">
                <h1 id="en103">Votre panier est vide <span id="en104" class="ant_infoBoxExtra">allez voir nos produits</span></h1>
                <a id="en105" href="./inventaire.php" class="button black bigButton">Produits</a>
            </div>
        <?php endif;
    else : ?>
        <div class="ant_infoBox">
            <img src="./img/cart.svg" alt="Panier">
            <h1 id="en106">Connectez-vous <span class="ant_infoBoxExtra" id="en107">pour afficher votre panier</span></h1>
            <a id="en108" href="./connexionClient.php" class="button black bigButton">Connexion</a>
        </div>
    <?php endif; ?>

</div>
<?php include_once("inc/footer.php"); ?>
