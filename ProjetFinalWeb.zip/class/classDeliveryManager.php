<?php
require_once './class/classDelivery.php';
class DeliveryManager
{
    /*----------------- Var -----------------*/
    private PDO $_bdd;

    /*----------------- SQL -----------------*/
    const ADD_DELIVERY = "
    INSERT INTO tblLivraison (liv_clientId, liv_adresseId, liv_date, liv_prixTotal)
    VALUES (:clientId, :adresseId, :date, :prixTotal);";

    /*-------------- Construct --------------*/
    public function __construct(PDO $bdd) { $this->_bdd = $bdd; }
    /*----------------- Get -----------------*/
    public function addDelivery($clientID, $adresseID, $date, $prixTotal) {
        try{
            $query = $this->_bdd->prepare(self::ADD_DELIVERY);
            $query->execute([':clientId' => $clientID, ':adresseId' => $adresseID, ':date' => $date, ':prixTotal' => $prixTotal]);

            return $this->_bdd->lastInsertId();
        }catch (PDOException $e){
            return false;
        }
    }

}
?>