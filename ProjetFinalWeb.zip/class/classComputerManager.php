<?php
require_once './class/classComputer.php';
class ComputerManager
{
    /*----------------- Var -----------------*/
    private PDO $_bdd;

    /*----------------- SQL -----------------*/
    const SELECT_ALL_COMPUTERS = "SELECT ord_id AS ID, CONCAT(pro_nom, ' / ', pro_frequence, ' / ', pro_coeurs, ' Coeur') AS processor, CONCAT(mem_quantite, ' ', mem_type) AS memory, mdl_nom AS model, mrq_nom AS brand, ord_prix AS price, stk_quantite AS stockage, ord_quantite AS quantity, ord_img AS image FROM tblOrdinateur AS o INNER JOIN tblMemoire AS e ON o.ord_memoireId = e.mem_id INNER JOIN tblProcesseur AS p ON o.ord_processeurId = p.pro_id INNER JOIN tblModele AS m ON o.ord_modeleId = m.mdl_id INNER JOIN tblMarque AS r ON o.ord_marqueId = r.mrq_id INNER JOIN tblOrdinateurStockage AS s ON o.ord_id = ods_ordId INNER JOIN tblStockage AS k ON s.ods_stockId = k.stk_id";

    const SELECT_COMPUTER_BY_ID ="
    SELECT 
        ord_id AS ID,
        CONCAT(pro_nom, ' / ', pro_frequence, ' / ', pro_coeurs, ' Coeur') AS Processor,
        CONCAT(mem_quantite, ' ', mem_type) AS Memory,
        mrq_nom AS Brand,
        mdl_nom AS Model,
        ord_prix AS Price,
        ord_quantite AS Quantity,
        ord_img AS Image
    FROM tblordinateur
        LEFT JOIN tblProcesseur ON pro_id = ord_processeurId
        LEFT JOIN tblMemoire ON mem_id = ord_memoireId
        LEFT JOIN tblmarque ON mrq_id = ord_marqueId
        LEFT JOIN tblmodele ON mdl_id = ord_modeleId
    WHERE ord_id = :id;
    ";

    /*------------Liste déroulante-------------*/
    const SELECT_ALL_MARQUES = "SELECT mrq_nom AS marque FROM tblMarque";
    const SELECT_ALL_MODELES = "SELECT mdl_nom AS modele FROM tblModele";
    const SELECT_ALL_PROCESSEURS = "SELECT pro_nom AS processeur FROM tblProcesseur";
    /*-----------------Filtre------------------*/
    const FILTRE_MARQUE = "r.mrq_nom = :marque";
    const FILTRE_PROCESSEUR = "p.pro_nom = :processeur";
    const FILTRE_MODELE = "m.mdl_nom = :modele";
    const FILTRE_MINIMUM = "o.ord_prix >= :minimum";
    const FILTRE_MAXIMUM = "o.ord_prix <= :maximum";
    /*-------------- Construct --------------*/
    public function __construct(PDO $bdd) { $this->_bdd = $bdd; }
    /*----------------- Get -----------------*/
    public function getComputerByID($computerID): ?Computer {
        try{
            $query = $this->_bdd->prepare(self::SELECT_COMPUTER_BY_ID);
            $query->execute([':id' => $computerID]);
            $bddResult = $query->fetch(PDO::FETCH_ASSOC);

            return $bddResult ? new Computer($bddResult) : null;
        }catch (PDOException $e){
            return null;
        }
    }

    public function getAllComputers($filtreArray = array()) : array {

        $bindArray = array();
        $whereClause = '';

        //Filtre marque
        if(isset($filtreArray['marque']) && $filtreArray['marque'] != 'Toutes') {
            $whereClause .= self::FILTRE_MARQUE;
            $bindArray[":marque"] = $filtreArray['marque'];
        }

        //Filtre processeur
        if(isset($filtreArray['processeur']) && $filtreArray['processeur'] != 'Toutes') {
            if(!empty($whereClause)) {
                $whereClause .= " AND ";
            }
            
            $whereClause .= self::FILTRE_PROCESSEUR;
            $bindArray[":processeur"] = $filtreArray['processeur'];
        }

        //Filtre modele
        if(isset($filtreArray['modele']) && $filtreArray['modele'] != 'Toutes') {
            if(!empty($whereClause)) {
                $whereClause .= " AND ";
            }

            $whereClause .= self::FILTRE_MODELE;
            $bindArray[":modele"] = $filtreArray['modele'];
        }

        //Filtre minimum
        if(isset($filtreArray['minimum']) && !empty($filtreArray['minimum'])) {
            if(!empty($whereClause)) {
                $whereClause .= " AND ";
            }

            $whereClause .= self::FILTRE_MINIMUM;
            $bindArray[":minimum"] = $filtreArray['minimum'];
        }

        //Filtre maximum
        if(isset($filtreArray['maximum']) && !empty($filtreArray['maximum'])) {
            if(!empty($whereClause)) {
                $whereClause .= " AND ";
            }
            
            $whereClause .= self::FILTRE_MAXIMUM;
            $bindArray[":maximum"] = $filtreArray['maximum'];
        }

        //Compléter filtre
        if(empty($whereClause)){
            $dbResult = $this->_bdd->query(self::SELECT_ALL_COMPUTERS)->fetchAll();
        }
        else {
            $query = $this->_bdd->prepare(self::SELECT_ALL_COMPUTERS . ' WHERE ' . $whereClause);
            $query->execute($bindArray);
            $dbResult = $query->fetchAll();
        }

        $ordinateurs = array();
        foreach ($dbResult as $row) {
            array_push($ordinateurs, new Computer($row));
        }

        return $ordinateurs;
    }

    public function getAllMarques() : array {
        return $this->_bdd->query(self::SELECT_ALL_MARQUES)->fetchAll();
    }

    public function getAllProcesseurs() : array {
        return $this->_bdd->query(self::SELECT_ALL_PROCESSEURS)->fetchAll();
    }

    public function getAllModeles() : array {
        return $this->_bdd->query(self::SELECT_ALL_MODELES)->fetchAll();
    }
}
?>