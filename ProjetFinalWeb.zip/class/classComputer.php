<?php
class Computer
{
    /*----------------- Var -----------------*/
    private $_ID;
    private $_processor;
    private $_memory;
    private $_brand;
    private $_model;
    private $_stockage;
    private $_price;
    private $_quantity;
    private $_image;
    /*-------------- Construct --------------*/
    public function __construct(array $attrib) {
        foreach ($attrib as $k => $v) {

            $methodName = 'set' . $k;

            if (method_exists($this, $methodName))
                $this->$methodName($v);
        }
    }
    /*----------------- Set -----------------*/
    public function setID($ID) { $this->_ID = $ID; }
    public function setProcessor($processor) { $this->_processor = $processor; }
    public function setMemory($memory) { $this->_memory = $memory; }
    public function setBrand($brand) { $this->_brand = $brand; }
    public function setModel($model) { $this->_model = $model; }
    public function setStockage($stockage) {$this->_stockage = $stockage;}
    public function setPrice($price) { $this->_price = $price; }
    public function setQuantity($quantity) { $this->_quantity = $quantity; }
    public function setImage($image) { $this->_image = $image; }
    /*----------------- Get -----------------*/
    public function getID() { return $this->_ID; }
    public function getProcessor() { return $this->_processor; }
    public function getMemory() { return $this->_memory; }
    public function getBrand() { return $this->_brand; }
    public function getModel() { return $this->_model; }
    public function getStockage() {return $this->_stockage;}
    public function getPrice() { return $this->_price; }
    public function getQuantity() { return $this->_quantity; }
    public function getImage() { return $this->_image; }

}
?>