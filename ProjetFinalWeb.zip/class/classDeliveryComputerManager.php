<?php
class DeliveryComputerManager
{
    /*----------------- Var -----------------*/
    private PDO $_bdd;

    /*----------------- SQL -----------------*/
    const ADD_COMPUTER = "
    INSERT INTO tblLivraisonOrdinateur
    VALUES (:deliveryId, :computerId);
    ";
    /*-------------- Construct --------------*/
    public function __construct(PDO $bdd) { $this->_bdd = $bdd; }
    /*----------------- Get -----------------*/
    public function addComputerWithDeliveryId($computerID, $deliveryId) {
        try{
            $query = $this->_bdd->prepare(self::ADD_COMPUTER);
            $query->execute([':computerId' => $computerID, ':deliveryId' => $deliveryId]);

            return $this->_bdd->lastInsertId();
        }catch (PDOException $e){
            return null;
        }
    }
}
?>