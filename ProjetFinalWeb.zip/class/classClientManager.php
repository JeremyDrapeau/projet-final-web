<?php
    require_once './class/classComputer.php';
class ClientManager
{
    const CLIENT_EXISTE = "SELECT cli_username FROM tblClient WHERE cli_username = :cli_username;";

    const CLIENT_CONNEXION = "SELECT cli_username, cli_mdp, cli_id FROM tblClient WHERE cli_username = :cli_username AND cli_mdp = :cli_mdp;";

    const INSERT_CLIENT = "INSERT INTO tblClient (cli_username, cli_prenom, cli_nom, cli_courriel, cli_adresseId, cli_telephone, cli_img, cli_mdp)
                              VALUES ( :cli_username, :cli_prenom, :cli_nom, :cli_courriel, :cli_adresseId, :cli_telephone, :cli_img, :cli_mdp)";

    const GET_CLIENT_INFO = "SELECT c.cli_id, c.cli_username, c.cli_prenom, c.cli_nom, c.cli_courriel, c.cli_img, c.cli_adresseId, c.cli_telephone, c.cli_mdp,
                            a.adr_adresse, a.adr_ville, a.adr_provinceId, a.adr_codePostal, p.prv_nom FROM tblClient c 
                            LEFT JOIN tblAdresse a ON c.cli_adresseId = a.adr_id LEFT JOIN tblProvince p ON a.adr_provinceId = p.prv_id WHERE c.cli_id = :cli_id";

    const INSERT_ADRESSE = "INSERT INTO tblAdresse (adr_adresse, adr_ville, adr_provinceId, adr_codePostal) VALUES (:adr_adresse, :adr_ville, :adr_provinceId, :adr_codePostal)";

    const MODIFY_ADRESSE = "UPDATE tblAdresse SET adr_adresse = :adr_adresse, adr_ville = :adr_ville, adr_provinceId = :adr_provinceId, adr_codePostal = :adr_codePostal WHERE adr_id = :adr_id";

    const MODIFY_CLIENT = "UPDATE tblClient 
                       SET cli_username = :cli_username, 
                           cli_prenom = :cli_prenom, 
                           cli_nom = :cli_nom, 
                           cli_courriel = :cli_courriel, 
                           cli_adresseId = :cli_adresseId, 
                           cli_telephone = :cli_telephone, 
                           cli_mdp = :cli_mdp";
                       
      
    const CLIENT_EXISTE_MODIFY = "SELECT cli_username FROM tblClient WHERE cli_username = :cli_username AND cli_id != :cli_id;";

    
    private $_bdd;

    private function set_db($bdd) {$this->_bdd = $bdd;}

    public function __construct($bdd) { $this->set_db($bdd);}

    private function addAdresse($clientObj) {

        $query = $this->_bdd->prepare(self::INSERT_ADRESSE);

        $query->bindValue(':adr_adresse', $clientObj->get_adresse());
        $query->bindValue(':adr_ville', $clientObj->get_ville());
        $query->bindValue(':adr_provinceId', $clientObj->get_province());
        $query->bindValue(':adr_codePostal', $clientObj->get_codePostal());

        $query->execute();

        return $this->_bdd->lastInsertId(); 
    }

    public function clientExiste(string $username) {
        $query = $this->_bdd->prepare(self::CLIENT_EXISTE);

        $query->bindValue(':cli_username', $username);

        $query->execute();

        $count = $query->fetchColumn();

        if ($count > 0) {
            return true;
        }
        return false;
    }
    
    public function insertClient($clientObj) {
        assert(is_a($clientObj, 'Client'), 'La classe "ClientManager" doit recevoir une instance (un objet) de la classe "Client" pour qu\'un nouveau client soit ajouté à la base de données.');

            $query = $this->_bdd->prepare(self::INSERT_CLIENT);

            $query->bindValue(':cli_username', $clientObj->get_username());
            $query->bindValue(':cli_prenom', $clientObj->get_prenom());
            $query->bindValue(':cli_nom', $clientObj->get_nom());
            $query->bindValue(':cli_courriel', $clientObj->get_courriel());
            $addressId = $this->addAdresse($clientObj);
            $clientObj->set_adresseId($addressId);
            $query->bindValue(':cli_adresseId', $addressId);
            $query->bindValue(':cli_telephone', $clientObj->get_tel());
            $clientObj->set_pfp('defaultpfp.png');
            $query->bindValue(':cli_img', $clientObj->get_pfp());
            $query->bindValue(':cli_mdp', $clientObj->get_mdp());   
            if($this->clientExiste($clientObj->get_username())){return false;}            
            else{
            $query->execute();
    
            return $this->_bdd->lastInsertId();
        }
    }
    public function connectionClient($username, $password) {
        $query = $this->_bdd->prepare(self::CLIENT_CONNEXION);

        $query->bindValue(':cli_username', $username);
        $query->bindValue(':cli_mdp', $password);

        $query->execute();

        $row = $query->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $_SESSION['client'] = $row['cli_id'];
            return true;
        }
        return false;
    }
    public function get_client_info($idClient){
        $query = $this->_bdd->prepare(self::GET_CLIENT_INFO);
        $query->execute(array(':cli_id' => $idClient));

        $row = $query->fetch(PDO::FETCH_ASSOC);
        if($row){
            return $row;
        }
        return null;
    }
    private function modifyAdresse($clientObj) {

        $query = $this->_bdd->prepare(self::MODIFY_ADRESSE);

        $query->bindValue(':adr_adresse', $clientObj->get_adresse());
        $query->bindValue(':adr_ville', $clientObj->get_ville());
        $query->bindValue(':adr_provinceId', $clientObj->get_province());
        $query->bindValue(':adr_codePostal', $clientObj->get_codePostal());
        $query->bindValue(':adr_id', $clientObj->get_adresseId());

        $query->execute();
        
        return $clientObj->get_adresseId();
    }
    public function modifyClient($clientObj){
        $queryStr = self::MODIFY_CLIENT;
        if ($clientObj->get_pfp() != null) {
            $queryStr .= ", cli_img = :cli_img";
        }
        $queryStr .= " WHERE cli_id = :cli_id";
        $query = $this->_bdd->prepare($queryStr);
        $query->bindValue(':cli_username', $clientObj->get_username());
        $query->bindValue(':cli_prenom', $clientObj->get_prenom());
        $query->bindValue(':cli_nom', $clientObj->get_nom());
        $query->bindValue(':cli_courriel', $clientObj->get_courriel());
        $query->bindValue(':cli_adresseId', $this->modifyAdresse($clientObj));
        $query->bindValue(':cli_telephone', $clientObj->get_tel());
        if($clientObj->get_pfp() != null)
        $query->bindValue(':cli_img', $clientObj->get_pfp());
        $query->bindValue(':cli_mdp', $clientObj->get_mdp());   
        $query->bindValue(':cli_id', $_SESSION['client']);

        if($this->clientExisteModify($clientObj->get_username())){return false;}            
        else{
            $query->execute();
            return true;
        }
    }
    public function clientExisteModify($username) {
        $query = $this->_bdd->prepare(self::CLIENT_EXISTE_MODIFY);

        $query->bindValue(':cli_username', $username);
        $query->bindValue(':cli_id', $_SESSION['client']);
    
        $query->execute();
        
        $count = $query->fetchColumn();
    
        if ($count > 0) {
            return true;
        }
        return false;
    }
};

?>