<?php
class Cart
{
    /*----------------- Var -----------------*/
    private $_ClientID;
    private $_ComputerID;
    /*-------------- Construct --------------*/
    public function __construct(array $attrib) {
        foreach ($attrib as $k => $v) {

            $methodName = 'set' . $k;

            if (method_exists($this, $methodName))
                $this->$methodName($v);
        }
    }
    /*----------------- Set -----------------*/
    public function setClientID($ClientID) { $this->_ClientID = $ClientID; }
    public function setComputerID($ComputerID) { $this->_ComputerID = $ComputerID; }
    /*----------------- Get -----------------*/
    public function getClientID() { return $this->_ClientID; }
    public function getComputerID() { return $this->_ComputerID; }

}
?>