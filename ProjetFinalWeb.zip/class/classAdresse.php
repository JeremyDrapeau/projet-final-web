<?php
class Adresse
{
    /*----------------- Var -----------------*/
    private $_adresse;
    private $_ville;
    private $_provinceId;
    private $_codePostal;
    /*-------------- Construct --------------*/
    public function __construct(array $attrib) {
        foreach ($attrib as $k => $v) {

            $methodName = 'set' . $k;

            if (method_exists($this, $methodName))
                $this->$methodName($v);
        }
    }
    /*----------------- Set -----------------*/
    public function setAdresse($adresse) { $this->_adresse = $adresse; }
    public function setVille($ville) { $this->_ville = $ville; }
    public function setProvinceId($provinceId) { $this->_provinceId = $provinceId; }
    public function setCodePostal($codePostal) { $this->_codePostal = $codePostal; }
    /*----------------- Get -----------------*/
    public function getAdresse() { return $this->_adresse; }
    public function getVille() { return $this->_ville; }
    public function getProvinceId() { return $this->_provinceId; }
    public function getCodePostal() { return $this->_codePostal; }


}
?>