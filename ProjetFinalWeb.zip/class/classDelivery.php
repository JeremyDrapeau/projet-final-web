<?php
class Delivery
{
    /*----------------- Var -----------------*/
    private $_deliveryID;
    private $_clientID;
    private $_adresseID;
    private $_date;
    private $_prixTotal;
    /*-------------- Construct --------------*/
    public function __construct(array $attrib) {
        foreach ($attrib as $k => $v) {

            $methodName = 'set' . $k;

            if (method_exists($this, $methodName))
                $this->$methodName($v);
        }
    }
    /*----------------- Set -----------------*/
    public function setDeliveryID($deliveryID) { $this->_deliveryID = $deliveryID; }
    public function setClientID($clientID) { $this->_clientID = $clientID; }
    public function setAdresseID($adresseID) { $this->_adresseID = $adresseID; }
    public function setDate($date) { $this->_date = $date; }
    public function setPrixTotal($prixTotal) { $this->_prixTotal = $prixTotal; }
    /*----------------- Get -----------------*/
    public function getDeliveryID() { return $this->_deliveryID; }
    public function getClientID() { return $this->_clientID; }
    public function getAdresseID() { return $this->_adresseID; }
    public function getDate() { return $this->_date; }
    public function getPrixTotal() { return $this->_prixTotal; }

}
?>