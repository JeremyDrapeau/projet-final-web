<?php
require_once './class/classAdresse.php';
class AdresseManager
{
    /*----------------- Var -----------------*/
    private PDO $_bdd;

    /*----------------- SQL -----------------*/
    const ADD_ADRESSE = "
    INSERT INTO tblAdresse (adr_adresse, adr_ville, adr_provinceId, adr_codePostal)
    VALUES (:address, :ville, :provinceId, :codePostal)";

    /*-------------- Construct --------------*/
    public function __construct(PDO $bdd) { $this->_bdd = $bdd; }
    /*----------------- Get -----------------*/
    public function addAdresse($adresse, $ville, $provinceId, $codePostal) {
        try{
            $query = $this->_bdd->prepare(self::ADD_ADRESSE);
            $query->execute([':address' => $adresse, ':ville' => $ville, ':provinceId' => $provinceId, ':codePostal' => $codePostal]);

            return $this->_bdd->lastInsertId();
        }catch (PDOException $e){
            return false;
        }
    }

}
?>