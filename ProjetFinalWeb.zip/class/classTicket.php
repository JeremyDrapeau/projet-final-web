<?php
    class Ticket {
        private $_ticketinfo = array("id" => 0, "clientId" => 0,
                "ordId" => 0, "titre" => "", "message" => "",
                "date" => "1000-00-00", "vote" => 0);

        public function __construct($id, $clientId, $ordId, $titre, $message, $date, $vote) {
            $this->_ticketinfo['id'] = $id;
            $this->_ticketinfo['clientId'] = $clientId;
            $this->_ticketinfo['ordId'] = $ordId;
            $this->_ticketinfo['titre'] = $titre;
            $this->_ticketinfo['message'] = $message;
            $this->_ticketinfo['date'] = $date;
            $this->_ticketinfo['vote'] = $vote;
        }

        public function getInfo($ticketInfo) {
            return $this->_ticketinfo[$ticketInfo];
        }
        public function setInfo($ticketInfo, $value) {
            $this->_ticketinfo[$ticketInfo] = $value;
        }
        public function displayTicket($ownerUsername) {
            echo "
            <div class='ticket'>
                <div class='ticketMain'>
                    <h3>" . $this->_ticketinfo['titre'] . "</h3>
                    <h6>Créé par : " . $ownerUsername . "</h6>
                    <p>" . $this->_ticketinfo['message'] . "</p>
                    <h6 class='ticketDate'>Le " . $this->_ticketinfo['date'] . "</h6>
                </div>
                <div class='voteArea'>
                    <p>Vote : " . $this->_ticketinfo['vote'] . "</p>
                </div>
            </div>
            ";
        }
    }
?>