<?php
require_once  'classCart.php';
class CartManager
{
    /*----------------- Var -----------------*/
    private PDO $_bdd;
    const SELECT_ITEMS_FROM_USER_ID ="
    SELECT
        pan_ordId AS ComputerID
    FROM tblPanier
    WHERE pan_clientId = :id;
    ";
    const SELECT_TOTAL_PRICE_FROM_USER_ID = "
    SELECT SUM(ord_prix) AS TotalPrice
    FROM tblPanier
    INNER JOIN tblOrdinateur ON ord_Id = pan_ordId
    WHERE pan_clientId = :id;
    ";
    const SELECT_TOTAL_ITEMS_FROM_USER_ID = "
    SELECT COUNT(pan_ordId) AS TotalItems
    FROM tblPanier
    WHERE pan_clientId = :id;
    ";
    const REMOVE_ITEM_FROM_USER_ID = "
	DELETE FROM tblPanier
	WHERE pan_clientId = :uid AND pan_ordId = :oid
	LIMIT 1;
    ";
    const ADD_TO_CART = "
    INSERT INTO tblPanier (pan_clientId, pan_ordId) 
    VALUES (:idClient, :idOrdi)
    ";
    /*-------------- Construct --------------*/
    public function __construct(PDO $bdd) { $this->_bdd = $bdd; }
    /*----------------- Get -----------------*/
    public function getComputersByClientID($userID): ?array {
        try{
            $query = $this->_bdd->prepare(self::SELECT_ITEMS_FROM_USER_ID);
            $query->execute([':id' => $userID]);

            return $query->fetchAll(PDO::FETCH_ASSOC);
        }catch (PDOException $e){
            return null;
        }
    }
    public function getTotalPriceByClientID($userID): ?float {
        try{
            $query = $this->_bdd->prepare(self::SELECT_TOTAL_PRICE_FROM_USER_ID);
            $query->execute([':id' => $userID]);
            $bddResult = $query->fetch(PDO::FETCH_ASSOC);

            return $bddResult['TotalPrice'];
        }catch (PDOException $e){
            return null;
        }
    }
    public function getTotalItemsByClientID($userID): ?int {
        try{
            $query = $this->_bdd->prepare(self::SELECT_TOTAL_ITEMS_FROM_USER_ID);
            $query->execute([':id' => $userID]);
            $bddResult = $query->fetch(PDO::FETCH_ASSOC);

            return $bddResult['TotalItems'];
        }catch (PDOException $e){
            return null;
        }
    }
    public function removeItemFromCart($userID, $itemID): bool {
        try{
            $query = $this->_bdd->prepare(self::REMOVE_ITEM_FROM_USER_ID);
            $query->execute([':uid' => $userID, ':oid' => $itemID]);

            return true;
        }catch (PDOException $e){
            return false;
        }
    }
    public function addToCart($idClient, $idOrdi) {
        $query = $this->_bdd->prepare(self::ADD_TO_CART);
        
        assert($query->execute([':idClient' => $idClient, ':idOrdi' => $idOrdi]), 'L\'item n\'a pas pu être ajouté dans la table Panier.'); 
  
        return $this->_bdd->lastInsertId();
      }
}
?>