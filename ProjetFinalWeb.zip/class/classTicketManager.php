<?php
    require_once "classTicket.php";
    require_once "classComputerManager.php";
    class TicketManager {
        private PDO $_bdd;
        private $_computerManager;
        private $_computer;
        private $_ticket = array();
        private $_ticketOwner = array();
        const GET_TICKETS_FROM_COMPUTER_ID = "SELECT * FROM tblTicket 
            WHERE tik_ordId = :ordId";
        const ADD_TICKET_TO_COMPUTER = "INSERT INTO tblticket (tik_clientId, tik_ordId, tik_titre, tik_message, tik_date, tik_vote)
            VALUES (:clientId, :ordId, :titre, :message, :date, 0)";
        const GET_USERNAME_FROM_TICKET_ID = "SELECT cli_username FROM tblClient
                INNER JOIN tblTicket ON tik_clientId = cli_id
                WHERE cli_id = :clientId";
        public function __construct($bd, $computerId) {
            $this->_bdd = $bd;
            $this->_computerManager = new ComputerManager($this->_bdd);
            $this->_computer = $this->_computerManager->getComputerByID($_GET["produit"]);
            $this->setTicketArray();
            $this->setOwnerArray();
        }
        public function displayProduct() {
            echo "
            <div class='supportProduct'>
                <a href='./produit.php?produit=" . $this->_computer->getID() . "'>    
                    <img src='./img/" . $this->_computer->getImage() . "'>
                </a>
                <div class='supportProductText'>
                    <h3>" . $this->_computer->getModel() . "</h3>
                    <h6>Par : " . $this->_computer->getBrand() . "</h6>
                </div>
            </div>
            ";
        }
        public function addTicketToComputer($clientId, $ordId, $titre, $message) {
            $query = $this->_bdd->prepare(self::ADD_TICKET_TO_COMPUTER);
            $bindArray = array(":clientId" => $clientId, ":ordId" => $ordId, ":titre" => $titre,
                         ":message" => $message, ":date" => getdate()['year'] . "-" . getdate()['mon'] . "-" . getdate()['mday']);
            $query->execute($bindArray);
        }
        public function setTicketArray() {
            $query = $this->_bdd->prepare(self::GET_TICKETS_FROM_COMPUTER_ID);
            $query->execute([':ordId' => $this->_computer->getID()]);
            $queryResult = $query->fetch(PDO::FETCH_ASSOC);
            while ($queryResult) {
                array_push($this->_ticket, new Ticket($queryResult['tik_id'], $queryResult['tik_clientId'],
                    $queryResult['tik_ordId'], $queryResult['tik_titre'], $queryResult['tik_message'],
                    $queryResult['tik_date'], $queryResult['tik_vote']));
                $queryResult = $query->fetch(PDO::FETCH_ASSOC);
            }
        }
        public function setOwnerArray() {
            for ($i = 0; $i < sizeof($this->_ticket); $i++) {
                $query = $this->_bdd->prepare(self::GET_USERNAME_FROM_TICKET_ID);
                $query->execute([':clientId' => $this->_ticket[$i]->getInfo('clientId')]);
                $queryResult = $query->fetch(PDO::FETCH_ASSOC);
                array_push($this->_ticketOwner, $queryResult['cli_username']);
            }
        }
        public function getTicketById($ticketId) {
            return $this->_ticket[$ticketId - 1];
        }
        public function displayAllTicket() {
            for ($i = 0; $i < sizeof($this->_ticket); $i++) {
                $this->_ticket[$i]->displayTicket($this->_ticketOwner[$i]);
            }
        }
    }
?>