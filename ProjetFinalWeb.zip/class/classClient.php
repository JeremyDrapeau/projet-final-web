<?php

class Client
{
    private $_ID;
    private $_username;
    private $_prenom;
    private $_nom;
    private $_courriel;
    private $_mdp;
    private $_tel;
    private $_pfp;
    
    private $_adresseId;
    private $_adresse;
    private $_ville;
    private $_province;
    private $_codePostal;


    public function __construct($params = array()){
  
        foreach($params as $k => $v){

            $methodName = "set_" . $k;            
            if(method_exists($this, $methodName)) {
                $this->$methodName($v);
            }   
        }
    }

    public function __serialize(){
        return [
            "idClient" => $this->_ID,
        ];
    }

    public function __unserialize($data){
        $this->_ID = $data["idClient"];
    }
    public function set_ID($_ID){$this->_ID = $_ID; return $this;}
    public function get_ID(){return $this->_ID;}

    public function set_username($_username){$this->_username = $_username;return $this;}
    public function get_username(){return $this->_username;}

    public function get_prenom(){return $this->_prenom;}
    public function set_prenom($_prenom){$this->_prenom = $_prenom;return $this;}

    public function get_nom(){return $this->_nom;}
    public function set_nom($_nom){$this->_nom = $_nom; return $this;}

    public function get_courriel(){return $this->_courriel;}
    public function set_courriel($_courriel){$this->_courriel = $_courriel; return $this;}

    public function get_mdp(){return $this->_mdp;}
    public function set_mdp($_mdp){$this->_mdp = $_mdp; return $this;}

    public function get_tel(){return $this->_tel;}
    public function set_tel($_tel){$this->_tel = $_tel; return $this;}

    public function set_pfp($_pfp){$this->_pfp = $_pfp; return $this;}
    public function get_pfp(){return $this->_pfp;}

    public function get_adresse(){return $this->_adresse;}
    public function set_adresse($_adresse){$this->_adresse = $_adresse; return $this;}

    public function get_adresseId(){return $this->_adresseId;}
    public function set_adresseId($_adresseId){$this->_adresseId = $_adresseId; return $this;}

    public function get_ville(){return $this->_ville;}
    public function set_ville($_ville){$this->_ville = $_ville;return $this;}

    public function get_province(){return $this->_province;}
    public function set_province($_province){$this->_province = $_province;return $this;}

    public function get_codePostal(){return $this->_codePostal;}
    public function set_codePostal($_codePostal){$this->_codePostal = $_codePostal;return $this;}
}
?>