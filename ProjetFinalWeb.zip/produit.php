<?php include_once("inc/header.php");
        include_once('./class/classComputer.php');
        include_once('./class/classComputerManager.php');
        include_once('./class/classCartManager.php');
        $cm = new ComputerManager($db);
        $cartm = new CartManager($db);
        $ifClientIsConnected = isset($_SESSION['client']);
        
    if(isset($_POST['panier']) && $_REQUEST['panier'] != 0) { 
        $last_entry = $cartm->addToCart($_SESSION['client'], $_POST['panier']);
            if(isset($last_entry)) {?>
            <div class="row" id="customAlert" style="background-color: #55D977">
                <div id="panierSuccess" style="background-color: #55D977">Item bien ajouté au panier!</div> <?php
            }
            else { ?>
            <div class="row" id="customAlert" style="background-color: #D98055">
                <div id="panierError" style="background-color: #D98055">Item n'a pas plus être ajouté au panier! Veuillez recommencer</div> <?php
            }?>
            <button type="button" id="buttonPanier" onclick="hideAlert()" class="button">x</button>
        </div> <?php 
    } 
    
    if(isset($_GET['produit'])) { 
        $computer = $cm->getComputerById($_REQUEST['produit'])?>
        <div class="row" id="showProduit">
            <img class="col-6 col-10m" src="./img/<?=$computer->getImage()?>" alt="Image <?=$computer->getBrand()?>">
            <div class="col-6 col-10m" id="infoProduit">
                <div class="row ligneProduit"> 
                    <p id="en38" class="col-3 titreProduit"> Modèle :  </p><p><?=$computer->getModel()?></p>
                </div>
                <div class="row ligneProduit">
                    <p id="en36" class="col-3 titreProduit"> Marque :  </p><p><?=$computer->getBrand()?></p> <br>
                </div>
                <div class="row ligneProduit">
                    <p id="en39" class="col-3 titreProduit"> Processeur :  </p><p><?=$computer->getProcessor()?></p> <br>
                </div>
                <div class="row ligneProduit">    
                    <p id="en50" class="col-3 titreProduit"> Mémoire :  </p><p><?=$computer->getMemory()?></p> <br>
                </div>
                <div class="row ligneProduit">
                    <p id="en49" class="col-3 titreProduit"> Stockage :  </p><p><?=$computer->getStockage()?></p> <br>
                </div>
            </div>
        </div>
        <div class="row priceAndCart">
            <p class="prixProduit"><?=$computer->getPrice()?>,00$ CAN</p>
            <?php if($ifClientIsConnected) { ?>
                <form actin="./produit.php" method="post">
                    <input type="hidden" name="panier" value="<?=$computer->getId()?>" />
                    <button id="en45" type="submit" name="valueComputer" value="<?=$computer->getID()?>" class="button">Ajouter a mon panier</button>
                </form> <?php
            } ?>
        </div> <?php

    } 
    else { ?>
        <div class="noProduit">
            <h2 class="col-8 center">Vous devez être arrivé sur cette page par erreur!</h2>
            <h3><a class="col-8" href="./inventaire.php">Cliquez ici pour voir notre inventaire!</a></h3>
        </div>
        <?php }?>

<?php include_once("inc/footer.php") ?>