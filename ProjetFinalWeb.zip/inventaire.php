<?php include_once("inc/header.php"); 
        include_once('./class/classComputer.php');
        include_once('./class/classComputerManager.php');
        include_once('./class/classCartManager.php');
        $cm = new ComputerManager($db);
        $cartm = new CartManager($db);
        $ifClientIsConnected = isset($_SESSION['client']);

    if(isset($_POST['panier']) && $_REQUEST['panier'] != 0) { 
        $last_entry = $cartm->addToCart($_SESSION['client'], $_POST['panier']);
            if(isset($last_entry)) {?>
            <div class="row" id="customAlert" style="background-color: #55D977">
                <div id="panierSuccess" style="background-color: #55D977">Item bien ajouté au panier!</div> <?php
            }
            else { ?>
            <div class="row" id="customAlert" style="background-color: #D98055">
                <div id="panierError" style="background-color: #D98055">Item n'a pas plus être ajouté au panier! Veuillez recommencer</div> <?php
            }?>
            <button type="button" id="buttonPanier" onclick="hideAlert()" class="button">x</button>
        </div> <?php 
    } ?>
    <div class="row" id="boxInventaire">
        <div class="filtreInventaire col-3 col-9m" >
            <form action="./inventaire.php" method="post">
                <?php
                $modeleArray = $cm->getAllModeles();
                $processeurArray = $cm->getAllProcesseurs();
                $marqueArray = $cm->getAllMarques();
                ?>
                <div class="row">
                    <label id="en36" for="marque" class="col-4">Marque :</label>
                    <select name="marque" id="marque" class="col-7">
                        <option id="en37a1" class="itemDeroulant" value="Toutes" selected>Toutes</option>
                            <?php 
                                foreach ($marqueArray as $marque) {
                                    echo '<option value="' . $marque[0] . '">' . $marque[0] . '</option>';
                                }
                            ?>
                    </select>
                </div>
                
                <div class="row">
                    <label id="en38" for="modele" class="col-4">Modele :</label>
                    <select name="modele" id="modele" class="col-7">
                        <option id="en37a2" value="Toutes" selected>Toutes</option>
                            <?php 
                                foreach($modeleArray as $modele){
                                    echo '<option value="' . $modele[0] . '">' . $modele[0] . '</option>';
                                }
                            ?>
                    </select>
                </div>

                <div class="row">
                    <label id="en39" for="processeur" class="col-4">Processeur :</label>
                    <select name="processeur" id="processeur" class="col-7">
                        <option id="en37a3" value="Toutes" selected>Toutes</option>
                            <?php 
                                foreach($processeurArray as $processeur){
                                    echo '<option value="' . $processeur[0] . '">' . $processeur[0] . '</option>';
                                }
                            ?>
                    </select>
                </div>

                <div class="row">
                    <label id="en40" for="minimum" class="col-4">Prix minimum :</label>
                    <input type="number" name="minimum" id="minimum" min="1" class="col-4"/>
                </div>

                <div class="row">
                    <label id="en41" for="maximum" class="col-4">Prix maximum :</label>
                    <input type="number" name="maximum" id="maximum" max="9999" class="col-4"/>
                </div>
                <div>
                    <input type="hidden" name="action" value="filtre" />
                    <button id="en42" type="submit" class="button">Filtrer inventaire</button>
                </div>
            </form>
        </div>

        <div class="inventaire col-7 col-11m" id="tableInventaire">
            <table class="col-12">
                <caption id="en46">Notre inventaire</caption>
                <thead id="tableHead">
                    <th class="col-2 col-4m hidden">Image</th>
                    <th id="en36e" onclick="sortTable(1)" style="cursor: pointer;">Marque</th>
                    <th id="en38e" onclick="sortTable(2)" style="cursor: pointer;">Modele</th>
                    <th id="en39e" class="tooMuchOnMobile" onclick="sortTable(3)" style="cursor: pointer;">Processeur</th>
                    <th id="en43" class="tooMuchOnMobile" onclick="sortTable(4)" style="cursor: pointer;">Mémoire</th>
                    <th id="en44">Prix</th>
                    <th id="en45" class="col-1 tooMuchOnMobile" <?php if(!$ifClientIsConnected){echo "style=\"display: none\"";}?>>Ajouter au panier<th>
                </thead>
                <tbody id="tableBody"> <?php
                    if(isset($_REQUEST['action']) && $_REQUEST['action'] == 'filtre'){
                        $computerArray = $cm->getAllComputers($_REQUEST);
                    } else {
                        $computerArray = $cm->getAllComputers();
                    }
                    foreach($computerArray as $computer) {?>
                        <tr class="inventaireRow">
                            <th class="col-2 col-4m" style="background-color: var(--white);"><a href="./produit.php?produit=<?=$computer->getID()?>"><img src="./img/<?=$computer->getImage()?>" alt="Image <?=$computer->getBrand()?>"></a></th>
                            <td class="col-2 col-3m"><?=$computer->getBrand()?></td>
                            <td class="col-2 col-3m"><?=$computer->getModel()?></td>
                            <td class="col-3 tooMuchOnMobile"><?=$computer->getProcessor()?></td>
                            <td class="tooMuchOnMobile"><?=$computer->getMemory()?></td>
                            <td><?=$computer->getPrice() . ",00$"?></td>
                            <?php if($ifClientIsConnected) { ?>
                                <th class="col-1 col-2m">
                                    <form actin="./inventaire.php" method="post">
                                        <input type="hidden" name="panier" value="<?=$computer->getId()?>" />
                                        <button type="submit" name="valueComputer" value="<?=$computer->getID()?>" class="button">+</button>
                                    </form>
                                </th>
                            <?php } ?>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

<?php include_once("inc/footer.php") ?>